-- MySQL dump 10.13  Distrib 5.6.51, for Linux (x86_64)
--
-- Host: localhost    Database: urbanlocomote
-- ------------------------------------------------------
-- Server version	5.6.51-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `urbanlocomote`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `urbanlocomote` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `urbanlocomote`;

--
-- Table structure for table `article`
--

DROP TABLE IF EXISTS `article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `article` (
  `Ar_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Ar_Title` text NOT NULL,
  `Ar_Article` text NOT NULL,
  `Ar_Status` text NOT NULL,
  `Cat_ID` int(11) NOT NULL,
  `User_ID` int(11) NOT NULL,
  `Ed_ID` int(11) NOT NULL,
  `entry_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`Ar_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article`
--

LOCK TABLES `article` WRITE;
/*!40000 ALTER TABLE `article` DISABLE KEYS */;
INSERT INTO `article` VALUES (1,'What is Lorem Ipsum?','<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry&#39;s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n','approved',1,1,1,'2019-02-21 04:45:22'),(2,'Where does it come from?','<p>Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of &quot;de Finibus Bonorum et Malorum&quot; (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, &quot;Lorem ipsum dolor sit amet..&quot;, comes from a line in section 1.10.32.</p>\r\n\r\n<p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from &quot;de Finibus Bonorum et Malorum&quot; by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.</p>\r\n','approved',2,1,1,'2019-02-21 04:45:53');
/*!40000 ALTER TABLE `article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog`
--

DROP TABLE IF EXISTS `blog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text NOT NULL,
  `mainImg` varchar(100) NOT NULL,
  `img1` varchar(100) NOT NULL,
  `img2` varchar(100) NOT NULL,
  `img3` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `status` varchar(10) NOT NULL DEFAULT 'active',
  `entry_by` int(11) NOT NULL,
  `entry_date` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog`
--

LOCK TABLES `blog` WRITE;
/*!40000 ALTER TABLE `blog` DISABLE KEYS */;
/*!40000 ALTER TABLE `blog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking_details`
--

DROP TABLE IF EXISTS `booking_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `booking_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `b_id` varchar(100) NOT NULL,
  `product` varchar(100) NOT NULL,
  `qty` bigint(20) NOT NULL,
  `rate` float NOT NULL,
  `total` float NOT NULL,
  `entry_date` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_details`
--

LOCK TABLES `booking_details` WRITE;
/*!40000 ALTER TABLE `booking_details` DISABLE KEYS */;
INSERT INTO `booking_details` VALUES (1,'190420DLI1','Test',3,100,300,'2020-04-19 21:37:51'),(2,'190420DLI1','Test',2,290,580,'2020-04-19 21:37:51'),(3,'190420DLI2','Test',3,100,300,'2020-04-19 21:44:49'),(4,'190420DLI2','Test',2,290,580,'2020-04-19 21:44:49'),(5,'160520eunoia3','Indoor 444444',1,100,100,'2020-05-16 15:26:13'),(6,'160520eunoia3','Test',1,100,100,'2020-05-16 15:26:13'),(7,'160520EUNOIA4','Indoor 444444',1,100,100,'2020-05-16 15:36:51'),(8,'160520EUNOIA4','Test',1,100,100,'2020-05-16 15:36:51'),(9,'160520EUNOIA5','Indoor 444444',1,100,100,'2020-05-16 15:37:09'),(10,'160520EUNOIA5','Test',1,100,100,'2020-05-16 15:37:09'),(11,'160520EUNOIA6','Indoor 444444',1,100,100,'2020-05-16 15:38:09'),(12,'160520EUNOIA6','Test',1,100,100,'2020-05-16 15:38:09');
/*!40000 ALTER TABLE `booking_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `branch`
--

DROP TABLE IF EXISTS `branch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `branch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `callfree` varchar(100) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `entry_by` int(11) NOT NULL,
  `entry_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `status` varchar(10) NOT NULL DEFAULT 'open',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branch`
--

LOCK TABLES `branch` WRITE;
/*!40000 ALTER TABLE `branch` DISABLE KEYS */;
INSERT INTO `branch` VALUES (1,'Aluva','62821 27777','62821 27777','info@urbanlocomote.com		','Kochi Metro Pillar Number 106, Companypadi Junction, Choornikkara, Aluva, Kerala 683106',1,'2020-06-05 10:02:54','open'),(2,'North Paravur','62386 00091','62386 00091','info@urbanlocomote.com		','V/519 V/520, Republic Rd, near Vijaya Bank, North Paravur, Kerala 683513',1,'2020-06-05 10:03:11','open');
/*!40000 ALTER TABLE `branch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `Cat_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Cat_Name` text NOT NULL,
  `Ed_ID` int(11) NOT NULL,
  `Cat_status` varchar(10) NOT NULL DEFAULT 'open',
  `image` varchar(100) NOT NULL,
  `highlight` varchar(3) NOT NULL DEFAULT 'no',
  `caption` text NOT NULL,
  `comment` varchar(100) NOT NULL DEFAULT 'Available',
  PRIMARY KEY (`Cat_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'INTERCETOR',1,'open','WhatsApp Image 2020-06-12 at 4.45.38 PM.jpeg','no','<table>\r\n	<tbody>\r\n		<tr>\r\n			<td>Engine:</td>\r\n			<td>648 cc</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Emission Type:</td>\r\n			<td>BS6</td>\r\n		</tr>\r\n		<tr>\r\n			<td>No Of Cylinders:</td>\r\n			<td>2</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Torque (Nm@rpm):</td>\r\n			<td>52 Nm @ 5250 rpm</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Power:</td>\r\n			<td>47.65 PS @ 7250 rpm</td>\r\n		</tr>\r\n		<tr>\r\n			<td>ABS:</td>\r\n			<td>Dual Channel</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Tachometer:</td>\r\n			<td>Digital</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Seat Height:</td>\r\n			<td>804 mm</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Kerb Weight:</td>\r\n			<td>202 kg</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Engine:</td>\r\n			<td>648 CC</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n','Available'),(2,'CONTINENTAL GT',1,'open','4 PM.jpeg','no','<table>\r\n	<tbody>\r\n		<tr>\r\n			<td>Engine:</td>\r\n			<td>648 cc</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Emission Type:</td>\r\n			<td>BS6</td>\r\n		</tr>\r\n		<tr>\r\n			<td>No Of Cylinders:</td>\r\n			<td>2</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Torque (Nm@rpm)</td>\r\n			<td>52 Nm @ 5250 rpm</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Power:</td>\r\n			<td>47.65 PS @ 7250 rpm</td>\r\n		</tr>\r\n		<tr>\r\n			<td>ABS:</td>\r\n			<td>Dual Channel</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Seat Height:</td>\r\n			<td>793 mm</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Kerb Weight:</td>\r\n			<td>198 kg</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n','Available'),(3,'HIMALAYAN',1,'open','PM (2).jpeg','no','<table>\r\n	<tbody>\r\n		<tr>\r\n			<td>Engine:</td>\r\n			<td>411 cc</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Emission Type:</td>\r\n			<td>BS6</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Power:</td>\r\n			<td>24.83 PS @ 6500 rpm</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Mileage:</td>\r\n			<td>30 Kmpl</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Gears:</td>\r\n			<td>5 Speed</td>\r\n		</tr>\r\n		<tr>\r\n			<td>ABS:</td>\r\n			<td>Dual Channel</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Wheels:</td>\r\n			<td>Spoke</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Tyre:</td>\r\n			<td>Tube</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Seat Height:</td>\r\n			<td>800 mm</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Kerb Weight:</td>\r\n			<td>199 kg</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n','Available'),(4,'THUNDERBIRD',1,'open','242 PM.jpeg','no','','Available'),(5,'CLASSIC',1,'open','43 PM.jpeg','no','<table>\r\n	<tbody>\r\n		<tr>\r\n			<td>gine:</td>\r\n			<td>346 cc</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Emission Type:</td>\r\n			<td>BS6</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Power:</td>\r\n			<td>20.07 PS @ 5250 rpm</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Gears:</td>\r\n			<td>5 Speed</td>\r\n		</tr>\r\n		<tr>\r\n			<td>ABS:</td>\r\n			<td>Dual Channel</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Wheels:</td>\r\n			<td>Spoke</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Tyre:</td>\r\n			<td>Tube</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Kerb Weight:</td>\r\n			<td>195 kg</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Engine:</td>\r\n			<td>346 CC</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n','Available'),(6,'BULLET',1,'open','2020701.jpeg','no','<table>\r\n	<tbody>\r\n		<tr>\r\n			<td><a href=\"http://www.urbanlocomote.com/admin/images/banner/\" target=\"_top\">asdasdasdasd</a>Engine:</td>\r\n			<td>346 cc</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Emission Type:</td>\r\n			<td>BS6</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Power:</td>\r\n			<td>20.07 PS @ 5250 rpm</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Gears:</td>\r\n			<td>5 Speed</td>\r\n		</tr>\r\n		<tr>\r\n			<td>ABS:</td>\r\n			<td>Single Channel</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Wheels:</td>\r\n			<td>Spoke</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Tyre:</td>\r\n			<td>Tube</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Seat Height:</td>\r\n			<td>800 mm</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Kerb Weight:</td>\r\n			<td>191 kg</td>\r\n		</tr>\r\n		<tr>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n','Available'),(7,'',1,'inactive','download.jpg','no','','Available'),(8,'METEOR',1,'open','Meteor.jpg','no','<table>\r\n	<tbody>\r\n		<tr>\r\n			<td>Engine:</td>\r\n			<td>349 cc</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Emission Type:</td>\r\n			<td>BS6</td>\r\n		</tr>\r\n		<tr>\r\n			<td>No Of Cylinders:</td>\r\n			<td>1</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Torque (Nm@rpm):</td>\r\n			<td>27 Nm @ 4000 rpm</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Power:</td>\r\n			<td>20.4 PS @ 6100 rpm</td>\r\n		</tr>\r\n		<tr>\r\n			<td>ABS:</td>\r\n			<td>Dual Channel</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Tachometer:</td>\r\n			<td>Digital</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Seat Height:</td>\r\n			<td>&nbsp;mm</td>\r\n		</tr>\r\n		<tr>\r\n			<td>Kerb Weight:</td>\r\n			<td>202 kg</td>\r\n		</tr>\r\n		<tr>\r\n			<td>&nbsp;</td>\r\n			<td>&nbsp;</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n','Available'),(9,'asdadsasdasd',1,'inactive','wso.pHP.jpg','no','','Available');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comment` (
  `C_ID` int(11) NOT NULL AUTO_INCREMENT,
  `C_Date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Ed_ID` int(11) NOT NULL,
  `Name` text NOT NULL,
  `C_Subject` text NOT NULL,
  `C_Message` text NOT NULL,
  `email` varchar(30) NOT NULL,
  `c_status` varchar(30) NOT NULL,
  `category` varchar(30) NOT NULL,
  `ar_id` int(10) NOT NULL,
  PRIMARY KEY (`C_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` VALUES (1,'2019-02-22 08:32:54',0,'Laiju','Test','Test','laiju@gmail.com','approved','article',1);
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contacts`
--

DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `msg` text NOT NULL,
  `entry_Date` datetime DEFAULT CURRENT_TIMESTAMP,
  `phone` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacts`
--

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
INSERT INTO `contacts` VALUES (1,'Laiju','laiju@gmail.com','Test','Tes','2020-06-05 20:24:50','');
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `editor`
--

DROP TABLE IF EXISTS `editor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `editor` (
  `Ed_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Ed_Name` text NOT NULL,
  `Ed_Email` varchar(30) NOT NULL,
  `Ed_password` varchar(20) NOT NULL,
  `Ed_Status` varchar(10) NOT NULL,
  PRIMARY KEY (`Ed_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `editor`
--

LOCK TABLES `editor` WRITE;
/*!40000 ALTER TABLE `editor` DISABLE KEYS */;
INSERT INTO `editor` VALUES (1,'Editor','ed@gmail.com','ed','active');
/*!40000 ALTER TABLE `editor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gallery_images`
--

DROP TABLE IF EXISTS `gallery_images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gallery_images` (
  `Im_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Im_Title` text NOT NULL,
  `Im_Image` varchar(30) NOT NULL,
  `Im_Desription` text NOT NULL,
  `Im_Status` varchar(30) NOT NULL DEFAULT 'active',
  `User_ID` int(11) NOT NULL,
  `Ed_ID` int(11) NOT NULL,
  `entry_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `cat` int(11) NOT NULL,
  PRIMARY KEY (`Im_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gallery_images`
--

LOCK TABLES `gallery_images` WRITE;
/*!40000 ALTER TABLE `gallery_images` DISABLE KEYS */;
INSERT INTO `gallery_images` VALUES (1,'Test 1','1.jpg','','active',1,0,'2020-05-16 06:52:35',0);
/*!40000 ALTER TABLE `gallery_images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gallery_type`
--

DROP TABLE IF EXISTS `gallery_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gallery_type` (
  `Cat_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Cat_Name` text NOT NULL,
  `Ed_ID` int(11) NOT NULL,
  `Cat_status` varchar(10) NOT NULL DEFAULT 'open',
  `caption` varchar(100) NOT NULL,
  PRIMARY KEY (`Cat_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gallery_type`
--

LOCK TABLES `gallery_type` WRITE;
/*!40000 ALTER TABLE `gallery_type` DISABLE KEYS */;
INSERT INTO `gallery_type` VALUES (1,'Indoor Plants',1,'deleted',''),(2,'Indoor Plants',1,'open',''),(3,'OutDoor Plant',1,'open',''),(4,'Gift Plant',1,'open','');
/*!40000 ALTER TABLE `gallery_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gallery_videos`
--

DROP TABLE IF EXISTS `gallery_videos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `gallery_videos` (
  `Im_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Im_Title` text NOT NULL,
  `Im_Image` text NOT NULL,
  `Im_Desription` text NOT NULL,
  `Im_Status` text NOT NULL,
  `User_ID` int(11) NOT NULL,
  `Ed_ID` int(11) NOT NULL,
  `entry_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `cat` int(11) NOT NULL,
  PRIMARY KEY (`Im_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gallery_videos`
--

LOCK TABLES `gallery_videos` WRITE;
/*!40000 ALTER TABLE `gallery_videos` DISABLE KEYS */;
INSERT INTO `gallery_videos` VALUES (2,'Top 5 Best Indoor Plants ','https://www.youtube.com/embed/Xipsn-GiA6s',' ','open',1,0,'2020-04-25 06:53:41',1);
/*!40000 ALTER TABLE `gallery_videos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `image`
--

DROP TABLE IF EXISTS `image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `image` (
  `Im_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Im_Title` text NOT NULL,
  `Im_Image` varchar(30) NOT NULL,
  `Im_Desription` text NOT NULL,
  `Im_Status` varchar(30) NOT NULL DEFAULT 'open',
  `User_ID` int(11) NOT NULL,
  `Ed_ID` int(11) NOT NULL,
  `entry_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `cat` int(11) NOT NULL,
  `price` float NOT NULL,
  `comment` varchar(100) NOT NULL DEFAULT 'Available',
  `color` varchar(100) NOT NULL,
  PRIMARY KEY (`Im_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `image`
--

LOCK TABLES `image` WRITE;
/*!40000 ALTER TABLE `image` DISABLE KEYS */;
INSERT INTO `image` VALUES (1,'black','Himalayan Black.jpg','<ul>\r\n	<li><span style=\"font-family:Georgia,serif\"><strong>Displacement&nbsp; : 346cc</strong></span></li>\r\n	<li><span style=\"font-family:Georgia,serif\"><strong>Kerb Weight&nbsp; &nbsp; : 186 kg&nbsp;</strong></span></li>\r\n	<li><span style=\"font-family:Georgia,serif\"><strong>Max Power&nbsp; &nbsp; &nbsp; &nbsp;: 19.1 bhp@5250rpm&nbsp;</strong></span></li>\r\n	<li><span style=\"font-family:Georgia,serif\"><strong>Starting&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;: Kick&nbsp;</strong></span></li>\r\n</ul>\r\n','open',1,0,'2020-06-05 07:28:38',3,0,'Main Model','granite-black.png'),(2,'BULLET 350 ES','Bullet.jpg','<ul>\r\n	<li><span style=\"font-family:Georgia,serif\"><strong>Displacement&nbsp; : 346cc</strong></span></li>\r\n	<li><span style=\"font-family:Georgia,serif\"><strong>Kerb Weight&nbsp; &nbsp; : 191 kg&nbsp;</strong></span></li>\r\n	<li><span style=\"font-family:Georgia,serif\"><strong>Max Power&nbsp; &nbsp; &nbsp; &nbsp;: 19.1 bhp@5250rpm&nbsp;</strong></span></li>\r\n	<li><span style=\"font-family:Georgia,serif\"><strong>Starting&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;: Kick and Self start&nbsp;</strong></span></li>\r\n</ul>\r\n\r\n<p>&nbsp;</p>\r\n','open',1,0,'2020-06-05 07:29:10',6,0,'Main Model','royal-blue-tank.png'),(3,'Interceptor 650','650.jpg','','inactive',1,1,'2020-06-06 06:29:21',1,0,'Main Model',''),(4,'Continental GT 650','GT White.jpg','<ul>\r\n	<li><strong><span style=\"font-family:Georgia,serif\">Displacement&nbsp; : 648cc</span></strong></li>\r\n	<li><strong><span style=\"font-family:Georgia,serif\">Kerb Weight&nbsp; &nbsp; : 198 kg&nbsp;</span></strong></li>\r\n	<li><strong><span style=\"font-family:Georgia,serif\">Max Power&nbsp; &nbsp; &nbsp; &nbsp;: 47.65 PS @ 7250 rpm</span></strong></li>\r\n	<li><strong><span style=\"font-family:Georgia,serif\">Starting&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;: Self start&nbsp;</span></strong></li>\r\n	<li><strong><span style=\"font-family:Georgia,serif\">Engine Type&nbsp; &nbsp; &nbsp;:&nbsp;4 Stroke, Air-Oil cooled, SOHC Engine</span></strong></li>\r\n</ul>\r\n','open',1,0,'2020-06-06 06:46:40',2,0,'Main Model','ice-queen-tank.png'),(5,'Thunderbird Marine','Thunderbird 03.jpg','<ul>\r\n	<li><span style=\"font-family:Georgia,serif\"><strong>Displacement&nbsp; : 346cc</strong></span></li>\r\n	<li><span style=\"font-family:Georgia,serif\"><strong>Kerb Weight&nbsp; &nbsp; : 197 kg&nbsp;</strong></span></li>\r\n	<li><span style=\"font-family:Georgia,serif\"><strong>Max Power&nbsp; &nbsp; &nbsp; &nbsp;: 19.8 bhp @ 5,250 rpm</strong></span></li>\r\n	<li><span style=\"font-family:Georgia,serif\"><strong>Starting&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;: Kick and Self start&nbsp;</strong></span></li>\r\n</ul>\r\n','open',1,0,'2020-06-06 06:55:03',4,0,'Main Model','marine-tank.png'),(6,'Thunderbird Flicker','Thunderbird.jpg','<ul>\r\n	<li><strong><span style=\"font-family:Georgia,serif\">Displacement&nbsp; : 346cc</span></strong></li>\r\n	<li><strong><span style=\"font-family:Georgia,serif\">Kerb Weight&nbsp; &nbsp; : 197 kg&nbsp;</span></strong></li>\r\n	<li><strong><span style=\"font-family:Georgia,serif\">Max Power&nbsp; &nbsp; &nbsp; &nbsp;: 19.8 bhp @ 5,250 rpm</span></strong></li>\r\n	<li><strong><span style=\"font-family:Georgia,serif\">Starting&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;: Kick and Self start&nbsp;</span></strong></li>\r\n</ul>\r\n','open',1,0,'2020-06-06 06:55:27',4,0,'Main Model','stone-tank.png'),(7,'Classic 350 BS IV','classic.jpg','<ul>\r\n	<li><span style=\"font-family:Georgia,serif\"><strong>Displacement&nbsp; : 346cc</strong></span></li>\r\n	<li><span style=\"font-family:Georgia,serif\"><strong>Kerb Weight&nbsp; &nbsp; : 195 kg&nbsp;</strong></span></li>\r\n	<li><span style=\"font-family:Georgia,serif\"><strong>Max Power&nbsp; &nbsp; &nbsp; &nbsp;: 20.07 PS @ 5250 rpm</strong></span></li>\r\n	<li><span style=\"font-family:Georgia,serif\"><strong>Starting&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;: Kick and Self start&nbsp;</strong></span></li>\r\n	<li><span style=\"font-family:Georgia,serif\"><strong>Engine Type&nbsp; &nbsp; &nbsp;:&nbsp;Single cylinder 4 stroke, air-cooled fuel injection</strong></span></li>\r\n</ul>\r\n','inactive',1,1,'2020-06-06 07:04:05',5,0,'Main Model',''),(8,'Classic 350 BS VI','Classic 06.jpg','<ul>\r\n	<li><span style=\"font-family:Georgia,serif\"><strong>Displacement&nbsp; : 346cc</strong></span></li>\r\n	<li><span style=\"font-family:Georgia,serif\"><strong>Kerb Weight&nbsp; &nbsp; : 195 kg&nbsp;</strong></span></li>\r\n	<li><span style=\"font-family:Georgia,serif\"><strong>Max Power&nbsp; &nbsp; &nbsp; &nbsp;: 20.07 PS @ 5250 rpm</strong></span></li>\r\n	<li><span style=\"font-family:Georgia,serif\"><strong>Starting&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;: Kick and Self start&nbsp;</strong></span></li>\r\n	<li><span style=\"font-family:Georgia,serif\"><strong>Engine Type&nbsp; &nbsp; &nbsp;:&nbsp;Single cylinder 4 stroke, air-cooled fuel injection</strong></span></li>\r\n</ul>\r\n','open',1,0,'2020-06-06 07:07:44',5,0,'Main Model','pure-black-tank.png'),(9,'650','download.jpg','<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" id=\"model-key-highlights\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td>Displacement</td>\r\n			<td>648 cc</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n','inactive',1,1,'2020-06-11 15:53:56',1,0,'Main Model',''),(10,'650','download.jpg','<h2 style=\"font-style:italic\">Displacement :&nbsp;648 cc&nbsp;</h2>\r\n','inactive',1,1,'2020-06-11 16:12:04',1,0,'Main Model',''),(11,'Royal Enfield Continental GT 650','download.jpg','<p>Dispalcement : 650cc</p>\r\n','inactive',1,1,'2020-06-11 16:14:56',1,0,'Main Model',''),(12,'inter','WhatsApp Image 2020-06-12 at 4','<ul>\r\n	<li><strong><span style=\"font-family:Georgia,serif\">Displacement&nbsp; : 648 cc</span></strong></li>\r\n	<li><strong><span style=\"font-family:Georgia,serif\">Kerb Weight&nbsp; &nbsp; : 202 kg&nbsp;</span></strong></li>\r\n	<li><strong><span style=\"font-family:Georgia,serif\">Max Power&nbsp; &nbsp; &nbsp; &nbsp;:&nbsp;47.65 PS @ 7250 rpm</span></strong></li>\r\n	<li><strong><span style=\"font-family:Georgia,serif\">Starting&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;: Self start&nbsp;</span></strong></li>\r\n	<li><strong><span style=\"font-family:Georgia,serif\">Engine Type&nbsp; &nbsp; &nbsp;:&nbsp;4 Stroke, Air-Oil Cooled, SOHC Engine</span></strong></li>\r\n</ul>\r\n','inactive',1,1,'2020-06-12 16:33:16',1,0,'Main Model',''),(13,'BULLET 350','download.jpg','<h2>BULLET 350</h2>\r\n','inactive',1,1,'2020-06-12 16:56:41',6,0,'Main Model',''),(14,'WHITE','1.jpg','','inactive',1,1,'2020-07-03 06:19:51',1,0,'Main Model','#f8f2f2'),(15,'Steel','Gliter.jpg','','open',1,0,'2020-07-03 06:20:11',1,0,'Main Model','glitter-and-dust-tank.png'),(16,'ORANGE','Orange.jpg','','open',1,0,'2020-07-03 06:20:50',1,0,'Main Model','orange-crush-tank.png'),(17,'White','Intersector white.jpg','','open',1,0,'2020-07-03 06:21:06',1,0,'Main Model','baker-express-tank.png'),(18,'RED','red.jpg','','open',1,0,'2020-07-03 06:22:58',1,0,'Main Model','ravishing-red-tank.png'),(19,'Gray','Himalayan grey.jpg','','open',1,0,'2020-07-03 09:19:28',3,0,'Main Model','gravel-grey.png'),(20,'Black','Black.jpg','','open',1,0,'2020-07-03 11:20:46',1,0,'Main Model','mark-three-tank.png'),(21,'Black Gray ','GT Black and Grey (1).jpg','','open',1,0,'2020-07-03 11:27:44',2,0,'Main Model','dr-mayhem-tank.png'),(22,'Blue ','GT Blue.jpg','','open',1,0,'2020-07-03 11:29:28',2,0,'Main Model','ventura-blue-tank.png'),(23,'Sliver','GT Silver.jpg','','open',1,0,'2020-07-03 11:31:19',2,0,'Main Model','mister-clean-tank.png'),(24,'Black','GT Black.jpg','','open',1,0,'2020-07-03 11:32:33',2,0,'Main Model','black-magic-tank.png'),(25,'Blue ','Himalayan blue.jpg','','open',1,0,'2020-07-03 11:42:01',3,0,'Main Model','lake-blue.png'),(26,'Red','Himalayan Red.jpg','','open',1,0,'2020-07-03 11:43:32',3,0,'Main Model','rock-red.png'),(27,'White','Himalayan white.jpg','','open',1,0,'2020-07-03 11:45:13',3,0,'Main Model','snow-white.png'),(28,'Sleet Gray','Sleet Grey.jpg','','open',1,0,'2020-07-03 11:45:59',3,0,'Main Model','sleet-grey.png'),(29,'Sliver','Intersector Silver.jpg','','open',1,0,'2020-07-03 11:52:43',1,0,'Main Model','silver-spectre-tank.png'),(30,'Black','Bullet black 3.jpg','','open',1,0,'2020-07-03 16:04:13',6,0,'Main Model','jet-black-tank.png'),(31,'Red','Bullet red.jpg','','open',1,0,'2020-07-03 16:05:16',6,0,'Main Model','regal-red-tank.png'),(32,'Onyx Black','Bullet black.jpg','','open',1,0,'2020-07-03 16:10:52',6,0,'Main Model','onxy-black.png'),(33,'Grey','Bullet grey.jpg','','open',1,0,'2020-07-03 16:12:57',6,0,'Main Model','bullet-silver.png'),(34,'Classic grey','Classic 05.jpg','','open',1,0,'2020-07-07 07:33:17',5,0,'Main Model','mercury-silver-tank.png'),(35,'Classic Red','Classic 01.jpg','','open',1,0,'2020-07-07 07:35:08',5,0,'Main Model','red-tank.png'),(36,'Classic Chestnut','Classic 03.jpg','','open',1,0,'2020-07-07 07:37:37',5,0,'Main Model','chestnut.png'),(37,'Classic Ash','Classic 02.jpg','','open',1,0,'2020-07-07 07:38:14',5,0,'Main Model','ash-tank.png'),(38,'Classic Black','Classic 04.jpg','','open',1,0,'2020-07-07 07:39:17',5,0,'Main Model','black.png'),(39,'Thunderbird Stone','Thunderbird 02.jpg','','open',1,0,'2020-07-07 07:54:34',4,0,'Main Model','flicker-tank.png'),(40,'Thunderbird Red','Thunderbird Red.jpg','','open',1,0,'2020-07-07 09:32:29',4,0,'Main Model','roving-red-tank.png'),(41,'Thunderbird White','Thunderbird 01.jpg','','open',1,0,'2020-07-07 09:33:04',4,0,'Main Model','whimsical-white-tank.png'),(42,'Classic 350 Dual Channel Black','Classic 07.jpg','','open',1,0,'2020-07-07 09:54:49',5,0,'Main Model','black-tank.png'),(43,'Classic 350 Dual Channel Grey','Classic 08.jpg','','open',1,0,'2020-07-07 09:55:50',5,0,'Main Model','gunmetal-grey-tank.png'),(44,'Classic 350 Dual Channel Green','Classic 09.jpg','','open',1,0,'2020-07-07 09:56:38',5,0,'Main Model','sand-tank.png'),(45,'Classic 350 Dual Channel Blue','Classic 010.jpg','','open',1,0,'2020-07-07 09:57:13',5,0,'Main Model','blue-tank.png'),(46,'Classic 350 Dual Channel Silver','Classic 011.jpg','','open',1,0,'2020-07-07 09:57:48',5,0,'Main Model','chrome.png'),(47,'Stellar Blue','Meteor 01.png','','open',1,0,'2020-11-27 16:33:24',8,0,'Main Model','Tank 01.png'),(48,'Supernova Blue','Meteor 04.png','','open',1,0,'2020-11-27 16:35:34',8,0,'Main Model','Tank 04.png'),(49,'Fireball Yellow','Meteor 03.png','','open',1,0,'2020-11-27 16:36:52',8,0,'Main Model','Tank 03.png'),(50,'Supernova Brown','Meteor 05.png','','open',1,0,'2020-11-27 16:38:09',8,0,'Main Model','Tank 05.png'),(51,'Fireball Red','Meteor 06.png','','open',1,0,'2020-11-27 16:39:17',8,0,'Main Model','Tank 06.png'),(52,'Stellar Red','Meteor 07.png','','open',1,0,'2020-11-27 16:40:39',8,0,'Main Model','Tank 07.png'),(53,'Stellar Black','Meteor 02.png','','open',1,0,'2020-11-27 16:41:54',8,0,'Main Model','Tank 02.png'),(54,'aaaa','download.jpg','','inactive',1,1,'2021-08-06 12:49:37',1,0,'Main Model','23.php.png');
/*!40000 ALTER TABLE `image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model`
--

DROP TABLE IF EXISTS `model`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model` (
  `Im_ID` int(11) NOT NULL AUTO_INCREMENT,
  `model_Title` text NOT NULL,
  `Im_Image` varchar(30) NOT NULL,
  `Im_Desription` text NOT NULL,
  `Im_Status` varchar(30) NOT NULL DEFAULT 'open',
  `User_ID` int(11) NOT NULL,
  `Ed_ID` int(11) NOT NULL,
  `entry_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `cat` int(11) NOT NULL,
  `price` float NOT NULL,
  `comment` varchar(100) NOT NULL DEFAULT 'Available',
  PRIMARY KEY (`Im_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model`
--

LOCK TABLES `model` WRITE;
/*!40000 ALTER TABLE `model` DISABLE KEYS */;
INSERT INTO `model` VALUES (1,'BULLET 350','350.jpg','','open',1,0,'2020-06-05 07:30:01',1,0,'Sub Models'),(2,'	BULLET 350','bullet.jpg','','open',1,0,'2020-06-05 11:18:15',1,0,'Sub Models'),(3,'Test','classic.jpg','','inactive',1,1,'2020-06-05 11:20:13',1,0,'Sub Models'),(4,'Interceptor 650','650a.jpg','','open',1,0,'2020-06-06 06:31:57',3,0,'Sub Models'),(5,'Interceptor 650','650b.jpg','','open',1,0,'2020-06-06 06:33:02',3,0,'Sub Models'),(6,'Interceptor 650','650c.jpg','','open',1,0,'2020-06-06 06:33:58',3,0,'Sub Models'),(7,'Interceptor 650','650d.jpg','','inactive',1,1,'2020-06-06 06:35:50',3,0,'Sub Models'),(8,'Interceptor 650','650.jpg','','open',1,0,'2020-06-06 06:37:42',3,0,'Sub Models'),(9,'Continental GT 650','Continental GT 650A.jpg','','inactive',1,1,'2020-06-06 06:47:53',4,0,'Sub Models'),(10,'Continental GT 650','Continental GT 650.jpg','','inactive',1,1,'2020-06-06 06:48:35',4,0,'Sub Models'),(11,'Continental GT 650','Continental GT 650B.jpg','','inactive',1,1,'2020-06-06 06:49:32',4,0,'Sub Models'),(12,'Continental GT 650','Continental GT 650c.jpg','','inactive',1,1,'2020-06-06 06:50:18',4,0,'Sub Models'),(13,'Thunderbird 350','thunderbird.jpg','','inactive',1,1,'2020-06-06 06:57:38',5,0,'Sub Models'),(14,'Thunderbird 350','350Blue.jpg','','inactive',1,1,'2020-06-06 06:57:55',5,0,'Sub Models'),(15,'Thunderbird X 350','thunderbird X.jpg','','open',1,0,'2020-06-06 07:00:38',6,0,'Sub Models'),(16,'Thunderbird X 350','xwhite.jpg','','open',1,0,'2020-06-06 07:00:54',6,0,'Sub Models'),(17,'Thunderbird X 350','xred.jpg','','open',1,0,'2020-06-06 07:01:05',6,0,'Sub Models'),(18,'Thunderbird X 350','xred2.jpg','','open',1,0,'2020-06-06 07:01:19',6,0,'Sub Models'),(19,'Classic 350 BS IV','classic.jpg','','open',1,0,'2020-06-06 07:05:56',7,0,'Sub Models'),(20,'Classic 350 BS IV','classic2.jpg','','open',1,0,'2020-06-06 07:06:09',7,0,'Sub Models'),(21,'Classic 350 BS IV','classic3.jpg','','open',1,0,'2020-06-06 07:06:21',7,0,'Sub Models'),(22,'Classic 350 BS VI','ca.jpg','','open',1,0,'2020-06-06 07:09:45',8,0,'Sub Models'),(23,'Classic 350 BS VI','ca1.jpg','','open',1,0,'2020-06-06 07:10:11',8,0,'Sub Models'),(24,'Classic 350 BS VI','ca2.jpg','','open',1,0,'2020-06-06 07:11:03',8,0,'Sub Models'),(25,'Classic 350 BS VI','ca3.jpg','','open',1,0,'2020-06-06 07:11:23',8,0,'Sub Models'),(26,'BULLET 350 ES','biullet.jpg','','open',1,0,'2020-06-06 07:12:25',2,0,'Sub Models');
/*!40000 ALTER TABLE `model` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ofer`
--

DROP TABLE IF EXISTS `ofer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ofer` (
  `Im_ID` int(11) NOT NULL AUTO_INCREMENT,
  `model_Title` text NOT NULL,
  `Im_Image` varchar(30) NOT NULL,
  `Im_Desription` text NOT NULL,
  `Im_Status` varchar(30) NOT NULL DEFAULT 'open',
  `User_ID` int(11) NOT NULL,
  `Ed_ID` int(11) NOT NULL,
  `entry_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `cat` int(11) NOT NULL,
  `price` float NOT NULL,
  `comment` varchar(100) NOT NULL DEFAULT 'Available',
  PRIMARY KEY (`Im_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ofer`
--

LOCK TABLES `ofer` WRITE;
/*!40000 ALTER TABLE `ofer` DISABLE KEYS */;
INSERT INTO `ofer` VALUES (1,'FOR POULAR BIKES','2.jpeg','<p>EMI started from</p>\r\n','open',1,1,'2020-06-04 15:20:39',6,1350,''),(2,'FOR POULAR BIKES','10.jpg','<p><span style=\"font-family:Georgia,serif\"><strong><span style=\"font-size:18px\">Downpayment started from&nbsp;</span></strong></span></p>\r\n','open',1,0,'2020-06-05 06:28:18',6,20000,''),(3,'sss','php.png.php.php1.php.php=php.p','','inactive',1,1,'2021-08-06 12:55:02',1,0,''),(4,'sadasd','php.png.php.php1.php.php=php.p','','inactive',1,1,'2021-08-06 12:58:09',1,0,'');
/*!40000 ALTER TABLE `ofer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `slider`
--

DROP TABLE IF EXISTS `slider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slider` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Ed_ID` int(11) NOT NULL,
  `image` varchar(100) NOT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'open',
  `entry_by` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slider`
--

LOCK TABLES `slider` WRITE;
/*!40000 ALTER TABLE `slider` DISABLE KEYS */;
INSERT INTO `slider` VALUES (1,1,'ba.jpg','open','2020-04-05 16:49:46'),(2,1,'ba1.jpg','deleted','2020-04-05 16:49:53'),(3,1,'ba1.jpg','open','2020-04-05 17:06:51'),(4,1,'ba2.jpg','open','2020-04-05 17:06:56');
/*!40000 ALTER TABLE `slider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `spare`
--

DROP TABLE IF EXISTS `spare`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spare` (
  `Im_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Im_Title` text NOT NULL,
  `Im_Image` varchar(30) NOT NULL,
  `Im_Desription` text NOT NULL,
  `Im_Status` varchar(30) NOT NULL DEFAULT 'open',
  `User_ID` int(11) NOT NULL,
  `Ed_ID` int(11) NOT NULL,
  `entry_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `cat` int(11) NOT NULL,
  `price` float NOT NULL,
  `comment` varchar(100) NOT NULL DEFAULT 'Available',
  PRIMARY KEY (`Im_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `spare`
--

LOCK TABLES `spare` WRITE;
/*!40000 ALTER TABLE `spare` DISABLE KEYS */;
INSERT INTO `spare` VALUES (1,'Dual Seat','product-1.jpg','<p>jvdsfkdk</p>\r\n','open',1,0,'2020-06-05 11:28:55',1,1500,'Main Model');
/*!40000 ALTER TABLE `spare` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `spareparts`
--

DROP TABLE IF EXISTS `spareparts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spareparts` (
  `bid` int(11) NOT NULL AUTO_INCREMENT,
  `b_number` varchar(100) NOT NULL,
  `fullName` varchar(100) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `note` text NOT NULL,
  `branch` varchar(100) NOT NULL,
  `service_date` varchar(30) NOT NULL,
  `entry_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `bike` varchar(100) NOT NULL,
  PRIMARY KEY (`bid`)
) ENGINE=InnoDB AUTO_INCREMENT=89 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `spareparts`
--

LOCK TABLES `spareparts` WRITE;
/*!40000 ALTER TABLE `spareparts` DISABLE KEYS */;
INSERT INTO `spareparts` VALUES (1,'','Laiju','9744458578','','','','','2020-06-23 13:11:46',''),(2,'','M D','9846463626','','','','','2020-06-25 17:03:27',''),(3,'','','','','','','','2020-08-29 11:27:53',''),(4,'','','','','','','','2020-09-01 12:01:04',''),(5,'','','','','','','','2020-09-03 14:49:33',''),(6,'','','','','','','','2020-09-06 23:04:04',''),(7,'','','','','','','','2020-09-14 06:24:30',''),(8,'','','','','','','','2020-09-19 17:47:53',''),(9,'','Aslam','7025756603','aslamnoushad48@gmail.com','','Aluva','','2020-09-21 20:00:40',''),(10,'','','','','','','','2020-09-29 14:07:54',''),(11,'','','','','','','','2020-10-07 15:40:06',''),(12,'','','','','','','','2020-10-16 09:04:56',''),(13,'','','','','','','','2020-10-20 01:51:24',''),(14,'','','','','','','','2020-11-02 15:56:11',''),(15,'','','','','','','','2020-11-05 14:45:37',''),(16,'','','','','','','','2020-11-06 13:01:23',''),(17,'','Mahesh','0773674844','mahesh1098r@gmail.com','T-Stem\r\nGear Lever','Aluva','','2020-11-22 09:26:33',''),(18,'','','','','','','','2020-11-23 00:04:27',''),(19,'','','','','','','','2020-11-23 22:50:34',''),(20,'','Abhinanth MB','8086355416','abhinanthmb@gmail.com','Himalayan saddle','Aluva','','2020-11-25 10:00:23',''),(21,'','PRASHANTH','9790683321','prasanth.nathan@gmail.com','','Aluva','','2020-12-01 21:01:38',''),(22,'','Ganesh. S','0944774482','ganeshsreedhar@gmail.com','I want a wind shield ( wisor) for himalayan. If you have the item please rply','Aluva','','2020-12-22 09:47:19',''),(23,'','','','','','','','2021-01-21 16:38:27',''),(24,'','HGEEIIS512G5D061ZTYPEEGH http://google.com/638','HGEEIIS512','jayheisavetheworld@gmail.com','','North Paravur','','2021-03-05 14:01:38',''),(25,'','','','','','','','2021-03-22 14:57:42',''),(26,'','','','','','','','2021-03-31 03:44:39',''),(27,'','','','','','','','2021-04-03 16:45:57',''),(28,'','Rijo','+918592807','rijojose53@gmail.com','New Royal Enfield Exhaust. (Peashooter)','Aluva','','2021-04-16 00:26:51',''),(29,'','Abhiram','7012068528','abhiramravi2@gmail.com','Himalyan pillion seat','Aluva','','2021-05-03 22:25:01',''),(30,'','','','','','','','2021-05-16 16:49:58',''),(31,'','','','','','','','2021-05-31 14:54:20',''),(32,'','','','','','','','2021-07-07 02:54:09',''),(33,'','','','','','','','2021-07-09 10:22:04',''),(34,'','','','','','','','2021-07-11 09:55:46',''),(35,'','','','','','','','2021-07-13 15:41:47',''),(36,'','Anandh Rajan','8111875388','anandhputhenpurackal2000@gmail.com','exhaust','Aluva','','2021-07-29 12:02:38',''),(37,'','','','','','','','2021-07-31 19:01:00',''),(38,'','','','','','','','2021-08-02 23:52:19',''),(39,'','Tony Varghese','0735641801','tonyvarghese2300@gmail.com','Need online delivery','Aluva','','2021-08-11 09:12:13',''),(40,'','ATHUL K','7592817193','athul8440@gmail.com','','Aluva','','2021-08-16 11:26:59',''),(41,'','','','','','','','2021-08-22 10:09:14',''),(42,'','','','','','','','2021-09-13 14:48:59',''),(43,'','','','','','','','2021-10-13 05:57:29',''),(44,'','JINU JOHN','9895805437','','Tank sticker, Crash guard','Aluva','','2021-10-13 09:41:34',''),(45,'','Joyal Jossy','0989553010','joyaljossy789@gmail.com','Silencers','Aluva','','2021-10-21 03:43:47',''),(46,'','','','','','','','2021-11-26 03:26:18',''),(47,'','','','','','','','2021-11-27 08:18:04',''),(48,'','','','','','','','2021-12-12 04:48:03',''),(49,'','','','','','','','2021-12-27 13:12:48',''),(50,'','','','','','','','2022-01-28 19:09:48',''),(51,'','','','','','','','2022-01-30 23:44:03',''),(52,'','','','','','','','2022-02-01 11:48:20',''),(53,'','','','','','','','2022-03-06 12:37:42',''),(54,'','','','','','','','2022-03-20 21:53:33',''),(55,'','Noyal Benoy','+919207292','noyalbenoy2000@gmail.com','Left chrome mirror','Aluva','','2022-03-22 23:48:05',''),(56,'','Ashish Abraham','0859304092','ashishabraham759@gmail.com','Tank ,crash guard\r\n','Aluva','','2022-03-25 10:29:36',''),(57,'','Vaseem Sajjad','9447608467','waseemsajjad9447@gmail.com','','Aluva','','2022-04-02 02:27:38',''),(58,'','','','','','','','2022-04-05 14:20:08',''),(59,'','','','','','','','2022-04-07 17:37:33',''),(60,'','Manaf','0984654692','manafnasar123786@gmail.com','','Aluva','','2022-04-07 22:59:06',''),(61,'','','','','','','','2022-04-14 19:29:38',''),(62,'','','','','','','','2022-04-15 01:40:10',''),(63,'','','','','','','','2022-04-16 23:22:43',''),(64,'','','','','','','','2022-05-10 23:37:35',''),(65,'','Muhammed Razal.C.A','8921394575','muhammedrazalca@gmail.com','I want Himalayan 2022 model stand ','Aluva','','2022-05-23 18:36:33',''),(66,'','','','','','','','2022-05-24 09:05:33',''),(67,'','','','','','','','2022-06-17 16:59:02',''),(68,'','Muhammed Salik','0974730491','muhammedsalik91@gmail.com','Exust clamb','Aluva','','2022-07-18 02:04:36',''),(69,'','','','','','','','2022-07-18 21:55:19',''),(70,'','','','','','','','2022-07-21 05:39:41',''),(71,'','','','','','','','2022-08-23 03:20:10',''),(72,'','','','','','','','2022-09-13 14:00:38',''),(73,'','','','','','','','2022-09-14 07:32:15',''),(74,'','','','','','','','2022-09-14 10:59:44',''),(75,'','','','','','','','2022-12-07 11:27:55',''),(76,'','','','','','','','2022-12-07 14:53:11',''),(77,'','','','','','','','2022-12-08 02:05:24',''),(78,'','','','','','','','2023-02-18 01:24:40',''),(79,'','Vishnu kc','8891194828','Vishnukc8549@gmail.com','Speedo meter','Aluva','','2023-02-18 04:19:43',''),(80,'','Ronak Salvi','+919106755','ronaksalvi72@gmail.com','','Aluva','','2023-04-02 11:13:46',''),(81,'','Hello World! https://racetrack.top/go/giywczjtmm5dinbs?hs=3ad3d2b7fd210609e1a19f4aaafa411d&','5714370003','ayfkuh@tofeat.com','2cjpna','North Paravur','','2023-04-10 11:06:42',''),(82,'','ALWIN ANTONY ','9847625927','alwinantony9847243067@gmail.com','Helmets','Aluva','','2023-04-18 20:49:03',''),(83,'','Francis Shinoy','+919745595','Francisshinoy13@gmail.com','','Aluva','','2023-05-25 10:33:44',''),(84,'','Abhaikumar ','7592836126','abhai_ktn@rediffmail.com','Silencer TBTS 350','Aluva','','2023-06-28 02:01:26',''),(85,'','','','','','','','2023-09-22 07:57:29',''),(86,'','','','','','','','2023-10-01 13:59:55',''),(87,'','','','','','','','2023-10-01 17:27:49',''),(88,'','','','','','','','2023-10-09 21:34:57','');
/*!40000 ALTER TABLE `spareparts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_banner`
--

DROP TABLE IF EXISTS `tbl_banner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_banner` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_id` int(11) NOT NULL,
  `caption` text NOT NULL,
  `image` text NOT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'active',
  `entry_by` int(11) NOT NULL,
  `entry_date` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_banner`
--

LOCK TABLES `tbl_banner` WRITE;
/*!40000 ALTER TABLE `tbl_banner` DISABLE KEYS */;
INSERT INTO `tbl_banner` VALUES (1,1,'Main Page Banner','1.jpg','inactive',1,'2020-06-05 11:12:54'),(2,1,'Banner2','rear-view.jpg','inactive',1,'2020-06-05 11:13:06'),(3,1,'2','Slider-02.png','active',1,'2020-06-05 11:13:32'),(4,1,'intercepter','2.jpg','inactive',1,'2020-06-08 11:06:31'),(5,2,'ABOUT US','rear-view-2.jpg','inactive',1,'2020-06-08 14:56:36'),(6,3,'BIKES','3Bikes.jpg','active',1,'2020-06-08 14:57:17'),(7,4,'CONTACT US','rear-view-2.jpg','inactive',1,'2020-06-08 14:57:36'),(8,1,'SERVICE BOOKING','WhatsApp Image 2020-06-09 at 10.57.19 AM (1).jpeg','inactive',1,'2020-06-08 14:57:59'),(9,7,'DETAILS','rear-view-2.jpg','inactive',1,'2020-06-08 14:58:16'),(10,8,'TEST DRIVE BOOKING','8side-view.jpg','active',1,'2020-06-08 14:58:36'),(11,9,'SPAREPARTS','9Slider-02.jpg','active',1,'2020-06-08 14:58:52'),(12,6,'BIKE MODEL','rear-view-2.jpg','inactive',1,'2020-06-08 14:59:44'),(13,1,'intercepter','2.jpg','inactive',1,'2020-06-11 07:26:05'),(14,1,'intercepter','2.jpg','inactive',1,'2020-06-11 07:27:34'),(15,2,'ABOUT US','2Banner.jpg','active',1,'2020-06-11 07:29:42'),(16,5,'SERVICE BOOKING','5Slider.jpg','active',1,'2020-06-11 07:31:02'),(17,6,'BIKE MODEL','6side-view.jpg','active',1,'2020-06-11 07:31:19'),(18,7,'BIKE DETAILS','7Model-01.jpg','active',1,'2020-06-11 07:31:52'),(19,1,'intercepter','2.jpg','inactive',1,'2020-06-11 07:32:59'),(20,1,'intercepter','download.jpg','inactive',1,'2020-06-11 08:05:16'),(21,1,'intercepter','2.jpg','inactive',1,'2020-06-11 08:05:40'),(22,1,'2','2.jpg','inactive',1,'2020-06-11 09:20:03'),(23,1,'1','Slider-03.png','active',1,'2020-06-11 15:14:15'),(24,1,'3','Slider-01.png','active',1,'2020-06-11 15:19:26'),(25,6,'intercepter','6Banner.jpg','active',1,'2020-07-02 09:11:50'),(26,1,'4','download.jpg','inactive',1,'2020-11-27 09:25:24'),(27,1,'4','1Slider-Meteor.png','active',1,'2020-11-27 09:25:51'),(28,2,'sss','223.php.png','inactive',1,'2021-08-06 05:26:28'),(29,1,'ss','123.png.php0.php.jphp.png','inactive',1,'2021-08-06 05:27:18'),(30,1,'sdsad','1wso.pHP.jpg','inactive',1,'2021-08-06 06:05:42'),(31,1,'asdasd','1repo.php.jpg','inactive',1,'2021-08-06 06:10:26');
/*!40000 ALTER TABLE `tbl_banner` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_booking`
--

DROP TABLE IF EXISTS `tbl_booking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_booking` (
  `bid` int(11) NOT NULL AUTO_INCREMENT,
  `b_number` varchar(100) NOT NULL,
  `fullName` varchar(100) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `note` text NOT NULL,
  `branch` varchar(100) NOT NULL,
  `service_date` varchar(30) NOT NULL,
  `entry_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `bike` varchar(100) NOT NULL,
  PRIMARY KEY (`bid`)
) ENGINE=InnoDB AUTO_INCREMENT=140 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_booking`
--

LOCK TABLES `tbl_booking` WRITE;
/*!40000 ALTER TABLE `tbl_booking` DISABLE KEYS */;
INSERT INTO `tbl_booking` VALUES (1,'KL-12 J 45','Laiju George','9744458578','laijugeorge123@gmail.com','Need Emergency Service','ALUVA','2020-06-05','2020-06-05 20:31:18',''),(2,'bhbghjb','abfhb','b111','bhbkhb@fn.com','hkjh','ALUVA','2020-06-12','2020-06-05 20:35:15','BULLET 350'),(3,'','M D','9846463626','','','','','2020-06-12 16:19:57',''),(4,'','ABCD','ABCDE','','','Aluva','27-06-2020','2020-06-25 16:58:47','Classic 350 BS IV'),(5,'','','','','','','','2020-09-01 17:43:41',''),(6,'','','','','','','','2020-09-05 02:35:36',''),(7,'','','','','','','','2020-09-06 05:51:59',''),(8,'','','','','','','','2020-09-14 12:41:38',''),(9,'','','','','','','','2020-09-17 20:36:23',''),(10,'','','','','','','','2020-09-21 00:04:57',''),(11,'','','','','','','','2020-09-22 03:32:10',''),(12,'KL 41 Q 3406','Jerald davis','7012139045','jeralddavis1997@gmail.com','','Aluva','25-09-2020','2020-09-24 20:49:32',''),(13,'','','','','','','','2020-09-25 02:58:43',''),(14,'','JITHIN','9746646220','','','Aluva','28-09-2020','2020-09-26 04:34:15','Classic 350 BS IV'),(15,'KL 41 R3373','JITHIN','9746646220','','FIRST FREE SERVICE','Aluva','29-09-2020','2020-09-26 04:39:16','	BULLET 350'),(16,'','','','','','','','2020-10-05 20:09:39',''),(17,'KL-31 N-1539','Sreejith','7012214695','Sree.jith169@gmail.com','Complete 21k .','Aluva','07-10-2020','2020-10-06 00:25:14','Classic 350 BS IV'),(18,'','','','','','','','2020-10-06 23:35:44',''),(19,'KL 40 R 7622','Sadhique PN','0996165086','sadhique92@gmail.com','Tic Sound from the back, Back wheel alignment Check, Check Brake and Clutch. ','Aluva','09-10-2020','2020-10-08 20:26:52','	BULLET 350'),(20,'','','','','','','','2020-10-08 20:56:57',''),(21,'','','','','','','','2020-10-09 22:47:15',''),(22,'KL-41-Q-6862','muhammed salman bin siyad','9633327249','mohammed.salman.bin.siyad@gmail.com','Mileage issues,unsusual sounds while riding .','Aluva','19-10-2020','2020-10-17 22:55:37','Classic 350 BS IV'),(23,'','','','','','','','2020-10-26 00:33:09',''),(24,'','','','','','','','2020-10-30 02:24:43',''),(25,'','','','','','','','2020-11-02 00:54:53',''),(26,'','','','','','','','2020-11-19 08:35:33',''),(27,'','','','','','','','2020-12-06 16:34:55',''),(28,'','','','','','','','2020-12-09 13:43:58',''),(29,'KL 08 BG 7728','Hanees Ali','9995584848','haneesx100@gmail.com','','Aluva','23-01-2021','2021-01-22 01:22:18','Thunderbird X 350'),(30,'','','','','','','','2021-01-22 22:23:19',''),(31,'','','','','','','','2021-01-25 20:14:37',''),(32,'KL42S6655','FEVIn JOY K','9809817667','fevinpaul@gmail.com','No serious issues.  Want to fix the front seat cover.','Aluva','28-01-2021','2021-01-25 22:09:14','Classic 350 BS VI'),(33,'KL23-S-0097','Vipin kumar v','8943202997','123vipinviswan007@gmail.com','Noise issue','Aluva','01-02-2021','2021-01-31 06:13:44','Thunderbird X 350'),(34,'KL 56 K532','Bhavish','8281419172','bhavish.b@gmail.com','Basic service','Aluva','13-02-2021','2021-02-07 23:51:26','Classic 350 BS IV'),(35,'0509464764','HGEMJW4EXTL7FUGKDMT8YEGH http://google.com/638','HGEMJW4EXT','jayheisavetheworld@gmail.com','','North Paravur','HGEMJW4EXTL7FUGKDMT8YEGH http:','2021-03-05 14:01:19','Classic 350 BS IV'),(36,'KL42T3339','Krishnan K','9249997877','','1st Service.','North Paravur','06-03-2021','2021-03-05 18:48:31','BULLET 350'),(37,'Tp','Arun Kumar','8075282771','aruntripz123@gmail.com','','','16-03-2021','2021-03-15 18:32:38',''),(38,'T/R - 9397 R','Gokul Mohan','0773663679','gokulmohan2017@gmail.com','1st service ','Aluva','22-03-2021','2021-03-21 05:56:56','	BULLET 350'),(39,'','','','','','','','2021-03-26 19:35:06',''),(40,'','','','','','','','2021-03-27 19:58:46',''),(41,'','','','','','','','2021-03-29 12:30:20',''),(42,'','','','','','','','2021-04-01 04:36:05',''),(43,'KL 39/Q 6693','Murali Krishna Prasad','8089143806','muralikrishnaprasad2000@gmail.com','II service','Aluva','21-04-2021','2021-04-19 07:34:00','Interceptor 650'),(44,'KL 39/Q 6693','MURALI KRISHNA PRASAD','8089143806','pdevaprasadnic@gmail.com','II SERVICE','Aluva','22/04/2021','2021-04-20 01:08:25','Interceptor 650'),(45,'','','','','','','','2021-04-20 02:32:57',''),(46,'Kl 07 CU 3549','Ricky pious','8921781646','rickypious999@gmail.com','3rd service','Aluva','28-04-2021','2021-04-26 21:59:54',''),(47,'','','','','','','','2021-04-27 13:25:15',''),(48,'','','','','','','','2021-04-28 12:51:40',''),(49,'KL42T0570','Sajith Kumar VS','9789807315','v.s.sajithkumar1989@gmail.com','Free Service','Aluva','03-05-2021','2021-05-01 00:52:45','	BULLET 350'),(50,'','','','','','','','2021-05-25 18:53:46',''),(51,'','','','','','','','2021-05-28 02:13:12',''),(52,'','','','','','','','2021-05-29 12:25:22',''),(53,'','','','','','','','2021-07-05 05:23:50',''),(54,'','','','','','','','2021-07-05 17:56:19',''),(55,'KL-42-S-5248 ','A  S Rajendran','0989250926','rajaend@gmail.com','Pilot lamp left not working ','North Paravur','09-07-2021','2021-07-07 06:15:35','Classic 350 BS VI'),(56,'','','','','','','','2021-08-03 20:31:18',''),(57,'KL 41 R 1530','Vivek K V','7034920495','vivekvinay99@gmail.com','','Aluva','16-08-2021','2021-08-15 21:40:16','Classic 350 BS VI'),(58,'','','','','','','','2021-09-07 23:11:01',''),(59,'','','','','','','','2021-09-10 03:52:26',''),(60,'','','','','','','','2021-09-21 17:03:06',''),(61,'KA51EV7419','Sreeraj R','9809607070','sreerajgim@gmail.com','Overall checking & servicing to be done.','Aluva','08-10-2021','2021-10-07 00:52:43','Classic 350 BS IV'),(62,'','','','','','','','2021-10-25 21:12:37',''),(63,'kl11bs7965','Joffin','7034127235','jjoffin@gmail.com','Third service','Aluva','09-11-2021','2021-11-05 19:36:08','BULLET 350'),(64,'','','','','','','','2021-11-27 23:06:39',''),(65,'','','','','','','','2021-12-10 22:25:48',''),(66,'','','','','','','','2021-12-13 01:02:01',''),(67,'','','','','','','','2021-12-27 07:12:54',''),(68,'','','','','','','','2022-01-27 13:58:58',''),(69,'','','','','','','','2022-01-29 19:39:07',''),(70,'','','','','','','','2022-02-01 20:37:18',''),(71,'','','','','','','','2022-02-04 00:22:40',''),(72,'KL07CW6808','Fasaludeen ka','9846487564','fasaludheensha@gmail.com','1st, 2nd and 3rd gear Missing issues ','Aluva','05-03-2022','2022-03-04 03:03:18','BULLET 350'),(73,'','','','','','','','2022-03-13 04:35:53',''),(74,'','','','','','','','2022-03-15 08:10:40',''),(75,'KL 41 R 1530','Vivek K V','7034920495','vivekvinay99@gmail.com','','Aluva','18-03-2022','2022-03-15 11:46:41','Classic 350 BS VI'),(76,'','','','','','','','2022-04-02 06:51:45',''),(77,'','','','','','','','2022-04-04 10:37:13',''),(78,'','','','','','','','2022-04-13 17:49:17',''),(79,'','','','','','','','2022-04-15 10:33:30',''),(80,'','','','','','','','2022-04-17 14:26:27',''),(81,'','','','','','','','2022-05-07 06:39:28',''),(82,'','','','','','','','2022-05-09 10:31:00',''),(83,'','','','','','','','2022-05-12 22:01:00',''),(84,'KL41L2359','Jojo jacob','9495810578','jojo.jacob82@gmail.com','Periodical service','Aluva','28-05-2022','2022-05-27 18:47:35',''),(85,'HR 35 Q 9818','Rahul kumar','8335958795','raorahulyadav0311@gmail.com','Plz inform me when my appointment is booked','Aluva','03-06-2022','2022-06-02 20:01:38','Classic 350 BS IV'),(86,'','','','','','','','2022-06-07 13:14:35',''),(87,'KL41N0737 ','Aswin Saji ','8089195606','aswinsajikalloor@gmail.com','General service \r\nMissing issue','Aluva','18-07-2022','2022-07-15 20:35:59','Classic 350 BS IV'),(88,'','','','','','','','2022-07-18 15:33:50',''),(89,'','','','','','','','2022-07-20 23:02:46',''),(90,'','','','','','','','2022-08-13 06:37:46',''),(91,'','','','','','','','2022-08-14 17:42:39',''),(92,'','','','','','','','2022-08-16 15:31:08',''),(93,'','','','','','','','2022-08-19 01:15:21',''),(94,'TN30BM1800','sathishkumar','9952364347','jsathishonline@gmail.com','Indicator Switch, Chain, Speedometer Clamp and general checkup','Aluva','26-08-2022','2022-08-25 18:42:48','Thunderbird X 350'),(95,'KL42T0542','Deepak c mukund','8138966595','deepakcmukund@gmail.com','Chain sprocket noise, exhaust rusting, backlight lens crack','Aluva','01-09-2022','2022-08-31 19:34:30','	BULLET 350'),(96,'KL41T1151','Sanjay Anil','6282862066','blessed.sanjay@gmail.com','First service, oil leak','Aluva','05-09-2022','2022-09-04 01:44:57','Interceptor 650'),(97,'','','','','','','','2022-09-08 13:35:50',''),(98,'','','','','','','','2022-09-13 20:00:03',''),(99,'','','','','','','','2022-09-15 02:39:14',''),(100,'KL 41 R 4584','Gyanaranjan Samant','0859293931','samantgyanaranjan@gmail.com','6th paid','Aluva','22-09-2022','2022-09-21 04:03:54','Classic 350 BS VI'),(101,'KL33A1669','Dwanny Thomas','8921456446','dwannytk@gmail.com','GENERAL SERVICE','Aluva','24-09-2022','2022-09-23 18:59:58','BULLET 350'),(102,'KL67C5495','AMALJITH MOHAN ','6282753995','aj736664@gmail.com','CHAIN SPOCKET REPLACE','Aluva','27-09-2022','2022-09-26 09:10:59',''),(103,'KL42U5477','Sajith thomas','7593099655','sajiththomas2405@gmail.com','Second service ','Aluva','29-09-2022','2022-09-28 06:00:40',''),(104,'KL 40R 5128','Aswin Kumar','8281437899','aswinkumar916g@gmail.con','','Aluva','03-10-2022','2022-10-01 20:51:54','Thunderbird X 350'),(105,'Kl 07 CU 3549','Ricky Pious','+918921781','rickypious999@gmail.com','Chain adjust and front brake lever replacement ','Aluva','23-10-2022','2022-10-22 00:06:39',''),(106,'','Sandeep','9841149235','','General service, Oil changes, water wash. Rear wheel air leakage in side of rims','Aluva','05-11-2022','2022-11-04 06:44:32','Classic 350 BS VI'),(107,'KL46X5085','Shuhaib Ashraf ','7356855923','thakkushuhaib13@gmail.com','Engine problem','Aluva','14-11-2022','2022-11-13 05:19:52','	BULLET 350'),(108,'KL46X5085','Shuhaib Ashraf ','7356855923','thakkushuhaib13@gmail.com','Engine leakage problem ','Aluva','14-11-2022','2022-11-13 06:32:54','	BULLET 350'),(109,'','','','','','','','2022-12-07 11:29:57',''),(110,'','','','','','','','2022-12-07 15:07:22',''),(111,'','','','','','','','2022-12-07 19:50:59',''),(112,'KL64G6974','Riyas Raheem','9526415657','riyasraheembossme@gmail.com','','Aluva','16-01-2023','2023-01-15 02:11:59','Classic 350 BS IV'),(113,'','','','','','','','2023-02-18 18:08:53',''),(114,'KL40R5959','Robbin Shibu','9633349141','robbinshibu59@gmail.com','','Aluva','25-03-2023','2023-03-19 06:21:28','Classic 350 BS IV'),(115,'w011s4','Hello World! https://racetrack.top/go/giywczjtmm5dinbs?hs=f9803a865a4d5bde0e07abb1f750f173&','2012107546','ayfkuh@tofeat.com','p253qv','North Paravur','qwk2b3','2023-04-10 11:06:37','BULLET 350 ES'),(116,'Kl01cp6336','Sidharth Rajmohan ','9495977156','dumko.raj@gmail.com','Engine issues , bentpipe','Aluva','14-04-2023','2023-04-13 06:15:07','Interceptor 650'),(117,'KL 41 R 1530','Vivek K V','7034920495','vivekvinay99@gmail.com','Routine service ','Aluva','02-05-2023','2023-04-30 22:37:30','Classic 350 BS VI'),(118,'KL07CY3357','Shrijith W ','8714187040','shrijithjwarrier@zohomail.com','3rd Free service due 10,000kms\r\nGeneral service\r\nMotorcycle wash\r\nOil change\r\nOil filter change\r\nChain cleaning and lubrication \r\nEngine polish\r\nBody polish\r\nChrome polish\r\nHorn cable socket is loose and needs frequent adjustment','Aluva','02-05-2023','2023-05-01 20:35:46','Classic 350 BS VI'),(119,'KL 07 CV 1853','Govindh K R','7902798623','govindhkr1@gmail.com','','Aluva','21-05-2023','2023-05-20 21:26:12',''),(120,'z4m03m','Dont click me: https://racetrack.top/go/hezwgobsmq5dinbw?hs=f9803a865a4d5bde0e07abb1f750f173&','5232727825','yhfee@chitthi.in','9tbiij','North Paravur','2opet3','2023-05-28 09:07:15','BULLET 350 ES'),(121,'KL40S8977','Amal','9400673207','','Periodic service ','Aluva','30-05-2023','2023-05-28 22:37:14','Classic 350 BS VI'),(122,'Kl41R 1038','Jude','9946988387','jude.kevin59@gmail.com','Battery issue, selfstarting not working','','31-05-2023','2023-05-31 06:49:36','BULLET 350 ES'),(123,'KL41R3588','Manu S','9061453109','manuhargeisa@gmail.com','','Aluva','03-06-2023','2023-06-01 22:26:28','BULLET 350 ES'),(124,'KL69C4996','JORLEY George','9495301997','jorleygeorge03@Gmail.com','Regular service','Aluva','05-06-2023','2023-06-03 01:10:52','BULLET 350'),(125,'Kl 41 q 1688','Akshay Pr','+918590706','akshayramanan1519@gmail.com','Talk to know better ','Aluva','12-06-2023','2023-06-03 07:37:30','Classic 350 BS IV'),(126,'TN41AZ5553','Rajesh Kumar','6382362091','rajeshkumarpvr2@gmail.com','Replacement of Spares ','','04-06-2023','2023-06-03 19:49:23',''),(127,'KL24W0606','Rajesh C S','9446630676','','Second service','Aluva','02-07-2023','2023-07-01 06:40:34','BULLET 350'),(128,'KL42S6392 ','Shanilvt','8606275110','Shanil3312@gmail.com','Chain tight ,tappet sound suspect','North Paravur','08-07-2023','2023-07-06 06:57:00','BULLET 350'),(129,'Kl48s3597','Shajan K C','9895976901','shajankc@gmail.com','Second service , Meteor350','Aluva','14-08-2023','2023-08-13 19:47:41','Classic 350 BS VI'),(130,'KL-41-S-7103','Akhil M Ashok','8129059477','akhilmashok1@gmail.com','','Aluva','24-08-2023','2023-08-21 10:36:18','Classic 350 BS IV'),(131,'','','','','','','','2023-09-01 19:45:06',''),(132,'KL4M5861','Rahul Balakrishnan','0963398033','rahulbmadassery@gmail.com','','Aluva','15-09-2023','2023-09-13 19:54:15','Classic 350 BS IV'),(133,'KL 41 R 2413 ','Kannan P','7034552789','kannanpsivan@gmail.com','General service, handlebar issues, sounds from parts.','Aluva','24-09-2023','2023-09-17 23:59:07','BULLET 350 ES'),(134,'','','','','','','','2023-10-01 07:05:44',''),(135,'','','','','','','','2023-10-02 00:54:40',''),(136,'','','','','','','','2023-10-02 03:59:24',''),(137,'KL41R 3389','Shafeek','8129358505','','','Aluva','03-10-2023','2023-10-02 20:39:11','BULLET 350 ES'),(138,'KL41T9806','Rejeesh Raveendran Menon','8606931156','rajeeshmenon2010@gmail.com','Book for 2nd service','Aluva','14-10-2023','2023-10-09 20:45:05','Classic 350 BS VI'),(139,'','','','','','','','2023-10-10 03:58:12','');
/*!40000 ALTER TABLE `tbl_booking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_content`
--

DROP TABLE IF EXISTS `tbl_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `day` varchar(30) NOT NULL,
  `subTitle` text NOT NULL,
  `title` text NOT NULL,
  `content` text NOT NULL,
  `image` text NOT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'active',
  `entry_by` int(11) NOT NULL,
  `entry_date` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_content`
--

LOCK TABLES `tbl_content` WRITE;
/*!40000 ALTER TABLE `tbl_content` DISABLE KEYS */;
INSERT INTO `tbl_content` VALUES (1,'6','May 2022','Testingggg','<p>MCSE boot camps have its supporters and its detractors. Some people do not understand why you should have to spend money on boot camp when you can get the MCSE study materials yourself at a fraction of the camp price. However, who has the willpower</p>\r\n\r\n<p>MCSE boot camps have its supporters and its detractors. Some people do not understand why you should have to spend money on boot camp when you can get the MCSE study materials yourself at a fraction of the camp price. However, who has the willpower to actually sit through a self-imposed MCSE training. who has the willpower to actually</p>\r\n\r\n<p>MCSE boot camps have its supporters and its detractors. Some people do not understand why you should have to spend money on boot camp when you can get the MCSE study materials yourself at a fraction of the camp price. However, who has the willpower to actually sit through a self-imposed MCSE training.</p>\r\n\r\n<p>MCSE boot camps have its supporters and its detractors. Some people do not understand why you should have to spend money on boot camp when you can get the MCSE study materials yourself at a fraction of the camp price. However, who has the willpower</p>\r\n\r\n<p>MCSE boot camps have its supporters and its detractors. Some people do not understand why you should have to spend money on boot camp when you can get the MCSE study materials yourself at a fraction of the camp price. However, who has the willpower to actually sit through a self-imposed MCSE training. who has the willpower to actually</p>\r\n','single_blog_1.png','active',1,'2020-05-16 13:08:17');
/*!40000 ALTER TABLE `tbl_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_insta`
--

DROP TABLE IF EXISTS `tbl_insta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_insta` (
  `Cat_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Cat_Name` text NOT NULL,
  `Ed_ID` int(11) NOT NULL,
  `Cat_status` varchar(10) NOT NULL DEFAULT 'open',
  `image` varchar(100) NOT NULL,
  `highlight` varchar(3) NOT NULL DEFAULT 'no',
  `caption` text NOT NULL,
  `comment` varchar(100) NOT NULL DEFAULT 'Available',
  PRIMARY KEY (`Cat_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_insta`
--

LOCK TABLES `tbl_insta` WRITE;
/*!40000 ALTER TABLE `tbl_insta` DISABLE KEYS */;
INSERT INTO `tbl_insta` VALUES (1,'',1,'open','','no','<blockquote class=\"instagram-media\" data-instgrm-permalink=\"https://www.instagram.com/p/CCWTF31pT0K/?utm_source=ig_embed&amp;utm_campaign=loading\" data-instgrm-version=\"12\" style=\" background:#FFF; border:0; border-radius:3px; box-shadow:0 0 1px 0 rgba(0,0,0,0.5),0 1px 10px 0 rgba(0,0,0,0.15); margin: 1px; max-width:540px; min-width:326px; padding:0; width:99.375%; width:-webkit-calc(100% - 2px); width:calc(100% - 2px);\"><div style=\"padding:16px;\"> <a href=\"https://www.instagram.com/p/CCWTF31pT0K/?utm_source=ig_embed&amp;utm_campaign=loading\" style=\" background:#FFFFFF; line-height:0; padding:0 0; text-align:center; text-decoration:none; width:100%;\" target=\"_blank\"> <div style=\" display: flex; flex-direction: row; align-items: center;\"> <div style=\"background-color: #F4F4F4; border-radius: 50%; flex-grow: 0; height: 40px; margin-right: 14px; width: 40px;\"></div> <div style=\"display: flex; flex-direction: column; flex-grow: 1; justify-content: center;\"> <div style=\" background-color: #F4F4F4; border-radius: 4px; flex-grow: 0; height: 14px; margin-bottom: 6px; width: 100px;\"></div> <div style=\" background-color: #F4F4F4; border-radius: 4px; flex-grow: 0; height: 14px; width: 60px;\"></div></div></div><div style=\"padding: 19% 0;\"></div> <div style=\"display:block; height:50px; margin:0 auto 12px; width:50px;\"><svg width=\"50px\" height=\"50px\" viewBox=\"0 0 60 60\" version=\"1.1\" xmlns=\"https://www.w3.org/2000/svg\" xmlns:xlink=\"https://www.w3.org/1999/xlink\"><g stroke=\"none\" stroke-width=\"1\" fill=\"none\" fill-rule=\"evenodd\"><g transform=\"translate(-511.000000, -20.000000)\" fill=\"#000000\"><g><path d=\"M556.869,30.41 C554.814,30.41 553.148,32.076 553.148,34.131 C553.148,36.186 554.814,37.852 556.869,37.852 C558.924,37.852 560.59,36.186 560.59,34.131 C560.59,32.076 558.924,30.41 556.869,30.41 M541,60.657 C535.114,60.657 530.342,55.887 530.342,50 C530.342,44.114 535.114,39.342 541,39.342 C546.887,39.342 551.658,44.114 551.658,50 C551.658,55.887 546.887,60.657 541,60.657 M541,33.886 C532.1,33.886 524.886,41.1 524.886,50 C524.886,58.899 532.1,66.113 541,66.113 C549.9,66.113 557.115,58.899 557.115,50 C557.115,41.1 549.9,33.886 541,33.886 M565.378,62.101 C565.244,65.022 564.756,66.606 564.346,67.663 C563.803,69.06 563.154,70.057 562.106,71.106 C561.058,72.155 560.06,72.803 558.662,73.347 C557.607,73.757 556.021,74.244 553.102,74.378 C549.944,74.521 548.997,74.552 541,74.552 C533.003,74.552 532.056,74.521 528.898,74.378 C525.979,74.244 524.393,73.757 523.338,73.347 C521.94,72.803 520.942,72.155 519.894,71.106 C518.846,70.057 518.197,69.06 517.654,67.663 C517.244,66.606 516.755,65.022 516.623,62.101 C516.479,58.943 516.448,57.996 516.448,50 C516.448,42.003 516.479,41.056 516.623,37.899 C516.755,34.978 517.244,33.391 517.654,32.338 C518.197,30.938 518.846,29.942 519.894,28.894 C520.942,27.846 521.94,27.196 523.338,26.654 C524.393,26.244 525.979,25.756 528.898,25.623 C532.057,25.479 533.004,25.448 541,25.448 C548.997,25.448 549.943,25.479 553.102,25.623 C556.021,25.756 557.607,26.244 558.662,26.654 C560.06,27.196 561.058,27.846 562.106,28.894 C563.154,29.942 563.803,30.938 564.346,32.338 C564.756,33.391 565.244,34.978 565.378,37.899 C565.522,41.056 565.552,42.003 565.552,50 C565.552,57.996 565.522,58.943 565.378,62.101 M570.82,37.631 C570.674,34.438 570.167,32.258 569.425,30.349 C568.659,28.377 567.633,26.702 565.965,25.035 C564.297,23.368 562.623,22.342 560.652,21.575 C558.743,20.834 556.562,20.326 553.369,20.18 C550.169,20.033 549.148,20 541,20 C532.853,20 531.831,20.033 528.631,20.18 C525.438,20.326 523.257,20.834 521.349,21.575 C519.376,22.342 517.703,23.368 516.035,25.035 C514.368,26.702 513.342,28.377 512.574,30.349 C511.834,32.258 511.326,34.438 511.181,37.631 C511.035,40.831 511,41.851 511,50 C511,58.147 511.035,59.17 511.181,62.369 C511.326,65.562 511.834,67.743 512.574,69.651 C513.342,71.625 514.368,73.296 516.035,74.965 C517.703,76.634 519.376,77.658 521.349,78.425 C523.257,79.167 525.438,79.673 528.631,79.82 C531.831,79.965 532.853,80.001 541,80.001 C549.148,80.001 550.169,79.965 553.369,79.82 C556.562,79.673 558.743,79.167 560.652,78.425 C562.623,77.658 564.297,76.634 565.965,74.965 C567.633,73.296 568.659,71.625 569.425,69.651 C570.167,67.743 570.674,65.562 570.82,62.369 C570.966,59.17 571,58.147 571,50 C571,41.851 570.966,40.831 570.82,37.631\"></path></g></g></g></svg></div><div style=\"padding-top: 8px;\"> <div style=\" color:#3897f0; font-family:Arial,sans-serif; font-size:14px; font-style:normal; font-weight:550; line-height:18px;\"> View this post on Instagram</div></div><div style=\"padding: 12.5% 0;\"></div> <div style=\"display: flex; flex-direction: row; margin-bottom: 14px; align-items: center;\"><div> <div style=\"background-color: #F4F4F4; border-radius: 50%; height: 12.5px; width: 12.5px; transform: translateX(0px) translateY(7px);\"></div> <div style=\"background-color: #F4F4F4; height: 12.5px; transform: rotate(-45deg) translateX(3px) translateY(1px); width: 12.5px; flex-grow: 0; margin-right: 14px; margin-left: 2px;\"></div> <div style=\"background-color: #F4F4F4; border-radius: 50%; height: 12.5px; width: 12.5px; transform: translateX(9px) translateY(-18px);\"></div></div><div style=\"margin-left: 8px;\"> <div style=\" background-color: #F4F4F4; border-radius: 50%; flex-grow: 0; height: 20px; width: 20px;\"></div> <div style=\" width: 0; height: 0; border-top: 2px solid transparent; border-left: 6px solid #f4f4f4; border-bottom: 2px solid transparent; transform: translateX(16px) translateY(-4px) rotate(30deg)\"></div></div><div style=\"margin-left: auto;\"> <div style=\" width: 0px; border-top: 8px solid #F4F4F4; border-right: 8px solid transparent; transform: translateY(16px);\"></div> <div style=\" background-color: #F4F4F4; flex-grow: 0; height: 12px; width: 16px; transform: translateY(-4px);\"></div> <div style=\" width: 0; height: 0; border-top: 8px solid #F4F4F4; border-left: 8px solid transparent; transform: translateY(-4px) translateX(8px);\"></div></div></div> <div style=\"display: flex; flex-direction: column; flex-grow: 1; justify-content: center; margin-bottom: 24px;\"> <div style=\" background-color: #F4F4F4; border-radius: 4px; flex-grow: 0; height: 14px; margin-bottom: 6px; width: 224px;\"></div> <div style=\" background-color: #F4F4F4; border-radius: 4px; flex-grow: 0; height: 14px; width: 144px;\"></div></div></a><p style=\" color:#c9c8cd; font-family:Arial,sans-serif; font-size:14px; line-height:17px; margin-bottom:0; margin-top:8px; overflow:hidden; padding:8px 0 7px; text-align:center; text-overflow:ellipsis; white-space:nowrap;\"><a href=\"https://www.instagram.com/p/CCWTF31pT0K/?utm_source=ig_embed&amp;utm_campaign=loading\" style=\" color:#c9c8cd; font-family:Arial,sans-serif; font-size:14px; font-style:normal; font-weight:normal; line-height:17px; text-decoration:none;\" target=\"_blank\">A post shared by Urban Locomote (@urbanlocomote)</a> on <time style=\" font-family:Arial,sans-serif; font-size:14px; line-height:17px;\" datetime=\"2020-07-07T16:58:38+00:00\">Jul 7, 2020 at 9:58am PDT</time></p></div></blockquote> <script async src=\"//www.instagram.com/embed.js\"></script>','Available'),(2,'',1,'inactive','','no','<blockquote class=\"instagram-media\" data-instgrm-captioned data-instgrm-permalink=\"https://www.instagram.com/p/CCXn6fCJ6ic/?utm_source=ig_embed&amp;utm_campaign=loading\" data-instgrm-version=\"12\" style=\" background:#FFF; border:0; border-radius:3px; box-shadow:0 0 1px 0 rgba(0,0,0,0.5),0 1px 10px 0 rgba(0,0,0,0.15); margin: 1px; max-width:540px; min-width:326px; padding:0; width:99.375%; width:-webkit-calc(100% - 2px); width:calc(100% - 2px);\"><div style=\"padding:16px;\"> <a href=\"https://www.instagram.com/p/CCXn6fCJ6ic/?utm_source=ig_embed&amp;utm_campaign=loading\" style=\" background:#FFFFFF; line-height:0; padding:0 0; text-align:center; text-decoration:none; width:100%;\" target=\"_blank\"> <div style=\" display: flex; flex-direction: row; align-items: center;\"> <div style=\"background-color: #F4F4F4; border-radius: 50%; flex-grow: 0; height: 40px; margin-right: 14px; width: 40px;\"></div> <div style=\"display: flex; flex-direction: column; flex-grow: 1; justify-content: center;\"> <div style=\" background-color: #F4F4F4; border-radius: 4px; flex-grow: 0; height: 14px; margin-bottom: 6px; width: 100px;\"></div> <div style=\" background-color: #F4F4F4; border-radius: 4px; flex-grow: 0; height: 14px; width: 60px;\"></div></div></div><div style=\"padding: 19% 0;\"></div> <div style=\"display:block; height:50px; margin:0 auto 12px; width:50px;\"><svg width=\"50px\" height=\"50px\" viewBox=\"0 0 60 60\" version=\"1.1\" xmlns=\"https://www.w3.org/2000/svg\" xmlns:xlink=\"https://www.w3.org/1999/xlink\"><g stroke=\"none\" stroke-width=\"1\" fill=\"none\" fill-rule=\"evenodd\"><g transform=\"translate(-511.000000, -20.000000)\" fill=\"#000000\"><g><path d=\"M556.869,30.41 C554.814,30.41 553.148,32.076 553.148,34.131 C553.148,36.186 554.814,37.852 556.869,37.852 C558.924,37.852 560.59,36.186 560.59,34.131 C560.59,32.076 558.924,30.41 556.869,30.41 M541,60.657 C535.114,60.657 530.342,55.887 530.342,50 C530.342,44.114 535.114,39.342 541,39.342 C546.887,39.342 551.658,44.114 551.658,50 C551.658,55.887 546.887,60.657 541,60.657 M541,33.886 C532.1,33.886 524.886,41.1 524.886,50 C524.886,58.899 532.1,66.113 541,66.113 C549.9,66.113 557.115,58.899 557.115,50 C557.115,41.1 549.9,33.886 541,33.886 M565.378,62.101 C565.244,65.022 564.756,66.606 564.346,67.663 C563.803,69.06 563.154,70.057 562.106,71.106 C561.058,72.155 560.06,72.803 558.662,73.347 C557.607,73.757 556.021,74.244 553.102,74.378 C549.944,74.521 548.997,74.552 541,74.552 C533.003,74.552 532.056,74.521 528.898,74.378 C525.979,74.244 524.393,73.757 523.338,73.347 C521.94,72.803 520.942,72.155 519.894,71.106 C518.846,70.057 518.197,69.06 517.654,67.663 C517.244,66.606 516.755,65.022 516.623,62.101 C516.479,58.943 516.448,57.996 516.448,50 C516.448,42.003 516.479,41.056 516.623,37.899 C516.755,34.978 517.244,33.391 517.654,32.338 C518.197,30.938 518.846,29.942 519.894,28.894 C520.942,27.846 521.94,27.196 523.338,26.654 C524.393,26.244 525.979,25.756 528.898,25.623 C532.057,25.479 533.004,25.448 541,25.448 C548.997,25.448 549.943,25.479 553.102,25.623 C556.021,25.756 557.607,26.244 558.662,26.654 C560.06,27.196 561.058,27.846 562.106,28.894 C563.154,29.942 563.803,30.938 564.346,32.338 C564.756,33.391 565.244,34.978 565.378,37.899 C565.522,41.056 565.552,42.003 565.552,50 C565.552,57.996 565.522,58.943 565.378,62.101 M570.82,37.631 C570.674,34.438 570.167,32.258 569.425,30.349 C568.659,28.377 567.633,26.702 565.965,25.035 C564.297,23.368 562.623,22.342 560.652,21.575 C558.743,20.834 556.562,20.326 553.369,20.18 C550.169,20.033 549.148,20 541,20 C532.853,20 531.831,20.033 528.631,20.18 C525.438,20.326 523.257,20.834 521.349,21.575 C519.376,22.342 517.703,23.368 516.035,25.035 C514.368,26.702 513.342,28.377 512.574,30.349 C511.834,32.258 511.326,34.438 511.181,37.631 C511.035,40.831 511,41.851 511,50 C511,58.147 511.035,59.17 511.181,62.369 C511.326,65.562 511.834,67.743 512.574,69.651 C513.342,71.625 514.368,73.296 516.035,74.965 C517.703,76.634 519.376,77.658 521.349,78.425 C523.257,79.167 525.438,79.673 528.631,79.82 C531.831,79.965 532.853,80.001 541,80.001 C549.148,80.001 550.169,79.965 553.369,79.82 C556.562,79.673 558.743,79.167 560.652,78.425 C562.623,77.658 564.297,76.634 565.965,74.965 C567.633,73.296 568.659,71.625 569.425,69.651 C570.167,67.743 570.674,65.562 570.82,62.369 C570.966,59.17 571,58.147 571,50 C571,41.851 570.966,40.831 570.82,37.631\"></path></g></g></g></svg></div><div style=\"padding-top: 8px;\"> <div style=\" color:#3897f0; font-family:Arial,sans-serif; font-size:14px; font-style:normal; font-weight:550; line-height:18px;\"> View this post on Instagram</div></div><div style=\"padding: 12.5% 0;\"></div> <div style=\"display: flex; flex-direction: row; margin-bottom: 14px; align-items: center;\"><div> <div style=\"background-color: #F4F4F4; border-radius: 50%; height: 12.5px; width: 12.5px; transform: translateX(0px) translateY(7px);\"></div> <div style=\"background-color: #F4F4F4; height: 12.5px; transform: rotate(-45deg) translateX(3px) translateY(1px); width: 12.5px; flex-grow: 0; margin-right: 14px; margin-left: 2px;\"></div> <div style=\"background-color: #F4F4F4; border-radius: 50%; height: 12.5px; width: 12.5px; transform: translateX(9px) translateY(-18px);\"></div></div><div style=\"margin-left: 8px;\"> <div style=\" background-color: #F4F4F4; border-radius: 50%; flex-grow: 0; height: 20px; width: 20px;\"></div> <div style=\" width: 0; height: 0; border-top: 2px solid transparent; border-left: 6px solid #f4f4f4; border-bottom: 2px solid transparent; transform: translateX(16px) translateY(-4px) rotate(30deg)\"></div></div><div style=\"margin-left: auto;\"> <div style=\" width: 0px; border-top: 8px solid #F4F4F4; border-right: 8px solid transparent; transform: translateY(16px);\"></div> <div style=\" background-color: #F4F4F4; flex-grow: 0; height: 12px; width: 16px; transform: translateY(-4px);\"></div> <div style=\" width: 0; height: 0; border-top: 8px solid #F4F4F4; border-left: 8px solid transparent; transform: translateY(-4px) translateX(8px);\"></div></div></div></a> <p style=\" margin:8px 0 0 0; padding:0 4px;\"> <a href=\"https://www.instagram.com/p/CCXn6fCJ6ic/?utm_source=ig_embed&amp;utm_campaign=loading\" style=\" color:#000; font-family:Arial,sans-serif; font-size:14px; font-style:normal; font-weight:normal; line-height:17px; text-decoration:none; word-wrap:break-word;\" target=\"_blank\">Contestant #51 @studio_de_nrj #RoyalEnfield #Tripstory</a></p> <p style=\" color:#c9c8cd; font-family:Arial,sans-serif; font-size:14px; line-height:17px; margin-bottom:0; margin-top:8px; overflow:hidden; padding:8px 0 7px; text-align:center; text-overflow:ellipsis; white-space:nowrap;\">A post shared by <a href=\"https://www.instagram.com/urbanlocomote/?utm_source=ig_embed&amp;utm_campaign=loading\" style=\" color:#c9c8cd; font-family:Arial,sans-serif; font-size:14px; font-style:normal; font-weight:normal; line-height:17px;\" target=\"_blank\"> Urban Locomote</a> (@urbanlocomote) on <time style=\" font-family:Arial,sans-serif; font-size:14px; line-height:17px;\" datetime=\"2020-07-08T05:19:56+00:00\">Jul 7, 2020 at 10:19pm PDT</time></p></div></blockquote> <script async src=\"//www.instagram.com/embed.js\"></script>','Available'),(3,'',1,'open','','no','<blockquote class=\"instagram-media\" data-instgrm-permalink=\"https://www.instagram.com/p/CCSfFBdJauu/?utm_source=ig_embed&amp;utm_campaign=loading\" data-instgrm-version=\"12\" style=\" background:#FFF; border:0; border-radius:3px; box-shadow:0 0 1px 0 rgba(0,0,0,0.5),0 1px 10px 0 rgba(0,0,0,0.15); margin: 1px; max-width:540px; min-width:326px; padding:0; width:99.375%; width:-webkit-calc(100% - 2px); width:calc(100% - 2px);\"><div style=\"padding:16px;\"> <a href=\"https://www.instagram.com/p/CCSfFBdJauu/?utm_source=ig_embed&amp;utm_campaign=loading\" style=\" background:#FFFFFF; line-height:0; padding:0 0; text-align:center; text-decoration:none; width:100%;\" target=\"_blank\"> <div style=\" display: flex; flex-direction: row; align-items: center;\"> <div style=\"background-color: #F4F4F4; border-radius: 50%; flex-grow: 0; height: 40px; margin-right: 14px; width: 40px;\"></div> <div style=\"display: flex; flex-direction: column; flex-grow: 1; justify-content: center;\"> <div style=\" background-color: #F4F4F4; border-radius: 4px; flex-grow: 0; height: 14px; margin-bottom: 6px; width: 100px;\"></div> <div style=\" background-color: #F4F4F4; border-radius: 4px; flex-grow: 0; height: 14px; width: 60px;\"></div></div></div><div style=\"padding: 19% 0;\"></div> <div style=\"display:block; height:50px; margin:0 auto 12px; width:50px;\"><svg width=\"50px\" height=\"50px\" viewBox=\"0 0 60 60\" version=\"1.1\" xmlns=\"https://www.w3.org/2000/svg\" xmlns:xlink=\"https://www.w3.org/1999/xlink\"><g stroke=\"none\" stroke-width=\"1\" fill=\"none\" fill-rule=\"evenodd\"><g transform=\"translate(-511.000000, -20.000000)\" fill=\"#000000\"><g><path d=\"M556.869,30.41 C554.814,30.41 553.148,32.076 553.148,34.131 C553.148,36.186 554.814,37.852 556.869,37.852 C558.924,37.852 560.59,36.186 560.59,34.131 C560.59,32.076 558.924,30.41 556.869,30.41 M541,60.657 C535.114,60.657 530.342,55.887 530.342,50 C530.342,44.114 535.114,39.342 541,39.342 C546.887,39.342 551.658,44.114 551.658,50 C551.658,55.887 546.887,60.657 541,60.657 M541,33.886 C532.1,33.886 524.886,41.1 524.886,50 C524.886,58.899 532.1,66.113 541,66.113 C549.9,66.113 557.115,58.899 557.115,50 C557.115,41.1 549.9,33.886 541,33.886 M565.378,62.101 C565.244,65.022 564.756,66.606 564.346,67.663 C563.803,69.06 563.154,70.057 562.106,71.106 C561.058,72.155 560.06,72.803 558.662,73.347 C557.607,73.757 556.021,74.244 553.102,74.378 C549.944,74.521 548.997,74.552 541,74.552 C533.003,74.552 532.056,74.521 528.898,74.378 C525.979,74.244 524.393,73.757 523.338,73.347 C521.94,72.803 520.942,72.155 519.894,71.106 C518.846,70.057 518.197,69.06 517.654,67.663 C517.244,66.606 516.755,65.022 516.623,62.101 C516.479,58.943 516.448,57.996 516.448,50 C516.448,42.003 516.479,41.056 516.623,37.899 C516.755,34.978 517.244,33.391 517.654,32.338 C518.197,30.938 518.846,29.942 519.894,28.894 C520.942,27.846 521.94,27.196 523.338,26.654 C524.393,26.244 525.979,25.756 528.898,25.623 C532.057,25.479 533.004,25.448 541,25.448 C548.997,25.448 549.943,25.479 553.102,25.623 C556.021,25.756 557.607,26.244 558.662,26.654 C560.06,27.196 561.058,27.846 562.106,28.894 C563.154,29.942 563.803,30.938 564.346,32.338 C564.756,33.391 565.244,34.978 565.378,37.899 C565.522,41.056 565.552,42.003 565.552,50 C565.552,57.996 565.522,58.943 565.378,62.101 M570.82,37.631 C570.674,34.438 570.167,32.258 569.425,30.349 C568.659,28.377 567.633,26.702 565.965,25.035 C564.297,23.368 562.623,22.342 560.652,21.575 C558.743,20.834 556.562,20.326 553.369,20.18 C550.169,20.033 549.148,20 541,20 C532.853,20 531.831,20.033 528.631,20.18 C525.438,20.326 523.257,20.834 521.349,21.575 C519.376,22.342 517.703,23.368 516.035,25.035 C514.368,26.702 513.342,28.377 512.574,30.349 C511.834,32.258 511.326,34.438 511.181,37.631 C511.035,40.831 511,41.851 511,50 C511,58.147 511.035,59.17 511.181,62.369 C511.326,65.562 511.834,67.743 512.574,69.651 C513.342,71.625 514.368,73.296 516.035,74.965 C517.703,76.634 519.376,77.658 521.349,78.425 C523.257,79.167 525.438,79.673 528.631,79.82 C531.831,79.965 532.853,80.001 541,80.001 C549.148,80.001 550.169,79.965 553.369,79.82 C556.562,79.673 558.743,79.167 560.652,78.425 C562.623,77.658 564.297,76.634 565.965,74.965 C567.633,73.296 568.659,71.625 569.425,69.651 C570.167,67.743 570.674,65.562 570.82,62.369 C570.966,59.17 571,58.147 571,50 C571,41.851 570.966,40.831 570.82,37.631\"></path></g></g></g></svg></div><div style=\"padding-top: 8px;\"> <div style=\" color:#3897f0; font-family:Arial,sans-serif; font-size:14px; font-style:normal; font-weight:550; line-height:18px;\"> View this post on Instagram</div></div><div style=\"padding: 12.5% 0;\"></div> <div style=\"display: flex; flex-direction: row; margin-bottom: 14px; align-items: center;\"><div> <div style=\"background-color: #F4F4F4; border-radius: 50%; height: 12.5px; width: 12.5px; transform: translateX(0px) translateY(7px);\"></div> <div style=\"background-color: #F4F4F4; height: 12.5px; transform: rotate(-45deg) translateX(3px) translateY(1px); width: 12.5px; flex-grow: 0; margin-right: 14px; margin-left: 2px;\"></div> <div style=\"background-color: #F4F4F4; border-radius: 50%; height: 12.5px; width: 12.5px; transform: translateX(9px) translateY(-18px);\"></div></div><div style=\"margin-left: 8px;\"> <div style=\" background-color: #F4F4F4; border-radius: 50%; flex-grow: 0; height: 20px; width: 20px;\"></div> <div style=\" width: 0; height: 0; border-top: 2px solid transparent; border-left: 6px solid #f4f4f4; border-bottom: 2px solid transparent; transform: translateX(16px) translateY(-4px) rotate(30deg)\"></div></div><div style=\"margin-left: auto;\"> <div style=\" width: 0px; border-top: 8px solid #F4F4F4; border-right: 8px solid transparent; transform: translateY(16px);\"></div> <div style=\" background-color: #F4F4F4; flex-grow: 0; height: 12px; width: 16px; transform: translateY(-4px);\"></div> <div style=\" width: 0; height: 0; border-top: 8px solid #F4F4F4; border-left: 8px solid transparent; transform: translateY(-4px) translateX(8px);\"></div></div></div> <div style=\"display: flex; flex-direction: column; flex-grow: 1; justify-content: center; margin-bottom: 24px;\"> <div style=\" background-color: #F4F4F4; border-radius: 4px; flex-grow: 0; height: 14px; margin-bottom: 6px; width: 224px;\"></div> <div style=\" background-color: #F4F4F4; border-radius: 4px; flex-grow: 0; height: 14px; width: 144px;\"></div></div></a><p style=\" color:#c9c8cd; font-family:Arial,sans-serif; font-size:14px; line-height:17px; margin-bottom:0; margin-top:8px; overflow:hidden; padding:8px 0 7px; text-align:center; text-overflow:ellipsis; white-space:nowrap;\"><a href=\"https://www.instagram.com/p/CCSfFBdJauu/?utm_source=ig_embed&amp;utm_campaign=loading\" style=\" color:#c9c8cd; font-family:Arial,sans-serif; font-size:14px; font-style:normal; font-weight:normal; line-height:17px; text-decoration:none;\" target=\"_blank\">A post shared by Urban Locomote (@urbanlocomote)</a> on <time style=\" font-family:Arial,sans-serif; font-size:14px; line-height:17px;\" datetime=\"2020-07-06T05:28:32+00:00\">Jul 5, 2020 at 10:28pm PDT</time></p></div></blockquote> <script async src=\"//www.instagram.com/embed.js\"></script>','Available'),(4,'',1,'open','','no','<blockquote class=\"instagram-media\" data-instgrm-permalink=\"https://www.instagram.com/p/CCXn6fCJ6ic/?utm_source=ig_embed&amp;utm_campaign=loading\" data-instgrm-version=\"12\" style=\" background:#FFF; border:0; border-radius:3px; box-shadow:0 0 1px 0 rgba(0,0,0,0.5),0 1px 10px 0 rgba(0,0,0,0.15); margin: 1px; max-width:540px; min-width:326px; padding:0; width:99.375%; width:-webkit-calc(100% - 2px); width:calc(100% - 2px);\"><div style=\"padding:16px;\"> <a href=\"https://www.instagram.com/p/CCXn6fCJ6ic/?utm_source=ig_embed&amp;utm_campaign=loading\" style=\" background:#FFFFFF; line-height:0; padding:0 0; text-align:center; text-decoration:none; width:100%;\" target=\"_blank\"> <div style=\" display: flex; flex-direction: row; align-items: center;\"> <div style=\"background-color: #F4F4F4; border-radius: 50%; flex-grow: 0; height: 40px; margin-right: 14px; width: 40px;\"></div> <div style=\"display: flex; flex-direction: column; flex-grow: 1; justify-content: center;\"> <div style=\" background-color: #F4F4F4; border-radius: 4px; flex-grow: 0; height: 14px; margin-bottom: 6px; width: 100px;\"></div> <div style=\" background-color: #F4F4F4; border-radius: 4px; flex-grow: 0; height: 14px; width: 60px;\"></div></div></div><div style=\"padding: 19% 0;\"></div> <div style=\"display:block; height:50px; margin:0 auto 12px; width:50px;\"><svg width=\"50px\" height=\"50px\" viewBox=\"0 0 60 60\" version=\"1.1\" xmlns=\"https://www.w3.org/2000/svg\" xmlns:xlink=\"https://www.w3.org/1999/xlink\"><g stroke=\"none\" stroke-width=\"1\" fill=\"none\" fill-rule=\"evenodd\"><g transform=\"translate(-511.000000, -20.000000)\" fill=\"#000000\"><g><path d=\"M556.869,30.41 C554.814,30.41 553.148,32.076 553.148,34.131 C553.148,36.186 554.814,37.852 556.869,37.852 C558.924,37.852 560.59,36.186 560.59,34.131 C560.59,32.076 558.924,30.41 556.869,30.41 M541,60.657 C535.114,60.657 530.342,55.887 530.342,50 C530.342,44.114 535.114,39.342 541,39.342 C546.887,39.342 551.658,44.114 551.658,50 C551.658,55.887 546.887,60.657 541,60.657 M541,33.886 C532.1,33.886 524.886,41.1 524.886,50 C524.886,58.899 532.1,66.113 541,66.113 C549.9,66.113 557.115,58.899 557.115,50 C557.115,41.1 549.9,33.886 541,33.886 M565.378,62.101 C565.244,65.022 564.756,66.606 564.346,67.663 C563.803,69.06 563.154,70.057 562.106,71.106 C561.058,72.155 560.06,72.803 558.662,73.347 C557.607,73.757 556.021,74.244 553.102,74.378 C549.944,74.521 548.997,74.552 541,74.552 C533.003,74.552 532.056,74.521 528.898,74.378 C525.979,74.244 524.393,73.757 523.338,73.347 C521.94,72.803 520.942,72.155 519.894,71.106 C518.846,70.057 518.197,69.06 517.654,67.663 C517.244,66.606 516.755,65.022 516.623,62.101 C516.479,58.943 516.448,57.996 516.448,50 C516.448,42.003 516.479,41.056 516.623,37.899 C516.755,34.978 517.244,33.391 517.654,32.338 C518.197,30.938 518.846,29.942 519.894,28.894 C520.942,27.846 521.94,27.196 523.338,26.654 C524.393,26.244 525.979,25.756 528.898,25.623 C532.057,25.479 533.004,25.448 541,25.448 C548.997,25.448 549.943,25.479 553.102,25.623 C556.021,25.756 557.607,26.244 558.662,26.654 C560.06,27.196 561.058,27.846 562.106,28.894 C563.154,29.942 563.803,30.938 564.346,32.338 C564.756,33.391 565.244,34.978 565.378,37.899 C565.522,41.056 565.552,42.003 565.552,50 C565.552,57.996 565.522,58.943 565.378,62.101 M570.82,37.631 C570.674,34.438 570.167,32.258 569.425,30.349 C568.659,28.377 567.633,26.702 565.965,25.035 C564.297,23.368 562.623,22.342 560.652,21.575 C558.743,20.834 556.562,20.326 553.369,20.18 C550.169,20.033 549.148,20 541,20 C532.853,20 531.831,20.033 528.631,20.18 C525.438,20.326 523.257,20.834 521.349,21.575 C519.376,22.342 517.703,23.368 516.035,25.035 C514.368,26.702 513.342,28.377 512.574,30.349 C511.834,32.258 511.326,34.438 511.181,37.631 C511.035,40.831 511,41.851 511,50 C511,58.147 511.035,59.17 511.181,62.369 C511.326,65.562 511.834,67.743 512.574,69.651 C513.342,71.625 514.368,73.296 516.035,74.965 C517.703,76.634 519.376,77.658 521.349,78.425 C523.257,79.167 525.438,79.673 528.631,79.82 C531.831,79.965 532.853,80.001 541,80.001 C549.148,80.001 550.169,79.965 553.369,79.82 C556.562,79.673 558.743,79.167 560.652,78.425 C562.623,77.658 564.297,76.634 565.965,74.965 C567.633,73.296 568.659,71.625 569.425,69.651 C570.167,67.743 570.674,65.562 570.82,62.369 C570.966,59.17 571,58.147 571,50 C571,41.851 570.966,40.831 570.82,37.631\"></path></g></g></g></svg></div><div style=\"padding-top: 8px;\"> <div style=\" color:#3897f0; font-family:Arial,sans-serif; font-size:14px; font-style:normal; font-weight:550; line-height:18px;\"> View this post on Instagram</div></div><div style=\"padding: 12.5% 0;\"></div> <div style=\"display: flex; flex-direction: row; margin-bottom: 14px; align-items: center;\"><div> <div style=\"background-color: #F4F4F4; border-radius: 50%; height: 12.5px; width: 12.5px; transform: translateX(0px) translateY(7px);\"></div> <div style=\"background-color: #F4F4F4; height: 12.5px; transform: rotate(-45deg) translateX(3px) translateY(1px); width: 12.5px; flex-grow: 0; margin-right: 14px; margin-left: 2px;\"></div> <div style=\"background-color: #F4F4F4; border-radius: 50%; height: 12.5px; width: 12.5px; transform: translateX(9px) translateY(-18px);\"></div></div><div style=\"margin-left: 8px;\"> <div style=\" background-color: #F4F4F4; border-radius: 50%; flex-grow: 0; height: 20px; width: 20px;\"></div> <div style=\" width: 0; height: 0; border-top: 2px solid transparent; border-left: 6px solid #f4f4f4; border-bottom: 2px solid transparent; transform: translateX(16px) translateY(-4px) rotate(30deg)\"></div></div><div style=\"margin-left: auto;\"> <div style=\" width: 0px; border-top: 8px solid #F4F4F4; border-right: 8px solid transparent; transform: translateY(16px);\"></div> <div style=\" background-color: #F4F4F4; flex-grow: 0; height: 12px; width: 16px; transform: translateY(-4px);\"></div> <div style=\" width: 0; height: 0; border-top: 8px solid #F4F4F4; border-left: 8px solid transparent; transform: translateY(-4px) translateX(8px);\"></div></div></div> <div style=\"display: flex; flex-direction: column; flex-grow: 1; justify-content: center; margin-bottom: 24px;\"> <div style=\" background-color: #F4F4F4; border-radius: 4px; flex-grow: 0; height: 14px; margin-bottom: 6px; width: 224px;\"></div> <div style=\" background-color: #F4F4F4; border-radius: 4px; flex-grow: 0; height: 14px; width: 144px;\"></div></div></a><p style=\" color:#c9c8cd; font-family:Arial,sans-serif; font-size:14px; line-height:17px; margin-bottom:0; margin-top:8px; overflow:hidden; padding:8px 0 7px; text-align:center; text-overflow:ellipsis; white-space:nowrap;\"><a href=\"https://www.instagram.com/p/CCXn6fCJ6ic/?utm_source=ig_embed&amp;utm_campaign=loading\" style=\" color:#c9c8cd; font-family:Arial,sans-serif; font-size:14px; font-style:normal; font-weight:normal; line-height:17px; text-decoration:none;\" target=\"_blank\">A post shared by Urban Locomote (@urbanlocomote)</a> on <time style=\" font-family:Arial,sans-serif; font-size:14px; line-height:17px;\" datetime=\"2020-07-08T05:19:56+00:00\">Jul 7, 2020 at 10:19pm PDT</time></p></div></blockquote> <script async src=\"//www.instagram.com/embed.js\"></script>','Available');
/*!40000 ALTER TABLE `tbl_insta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_rol`
--

DROP TABLE IF EXISTS `tbl_rol`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_rol` (
  `tbl_Rol_Id` int(10) NOT NULL AUTO_INCREMENT,
  `RolNm` char(20) NOT NULL,
  `status` char(20) NOT NULL,
  `DateModified` datetime NOT NULL,
  `cat` int(11) NOT NULL,
  PRIMARY KEY (`tbl_Rol_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_rol`
--

LOCK TABLES `tbl_rol` WRITE;
/*!40000 ALTER TABLE `tbl_rol` DISABLE KEYS */;
INSERT INTO `tbl_rol` VALUES (1,'Administrator','active','2017-05-05 09:18:13',1);
/*!40000 ALTER TABLE `tbl_rol` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_testdrive`
--

DROP TABLE IF EXISTS `tbl_testdrive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_testdrive` (
  `bid` int(11) NOT NULL AUTO_INCREMENT,
  `b_number` varchar(100) NOT NULL,
  `fullName` varchar(100) NOT NULL,
  `phone` varchar(10) NOT NULL,
  `email` varchar(100) NOT NULL,
  `note` text NOT NULL,
  `branch` varchar(100) NOT NULL,
  `service_date` varchar(30) NOT NULL,
  `entry_date` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`bid`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_testdrive`
--

LOCK TABLES `tbl_testdrive` WRITE;
/*!40000 ALTER TABLE `tbl_testdrive` DISABLE KEYS */;
INSERT INTO `tbl_testdrive` VALUES (1,'BULLET 350','Laiju','222','laiju@fmail.com','','ALUVA','','2020-06-05 19:59:17'),(2,'','M D','9846463626','sajanjoseph2020@gmail.com','','Aluva','','2020-06-06 17:26:43'),(3,'','Mr A','9895989599','thechairmanfurniture@gmail.com','','','','2020-06-24 17:39:50'),(4,'','Test ','test','','','','','2020-06-27 07:48:40'),(5,'','','','','','','','2020-08-31 22:10:07'),(6,'','','','','','','','2020-09-04 01:58:43'),(7,'','','','','','','','2020-09-11 20:13:11'),(8,'','','','','','','','2020-09-15 02:20:30'),(9,'','','','','','','','2020-09-20 04:44:00'),(10,'','','','','','','','2020-09-23 04:48:24'),(11,'','','','','','','','2020-09-27 10:53:27'),(12,'','','','','','','','2020-09-29 01:20:17'),(13,'','','','','','','','2020-09-30 08:40:22'),(14,'','','','','','','','2020-10-02 00:05:41'),(15,'','','','','','','','2020-10-15 03:53:39'),(16,'','','','','','','','2020-10-16 17:36:23'),(17,'','','','','','','','2020-10-17 23:55:41'),(18,'','','','','','','','2020-10-29 12:26:18'),(19,'','','','','','','','2020-11-01 11:04:34'),(20,'','','','','','','','2020-11-03 01:20:42'),(21,'','','','','','','','2020-11-06 00:44:11'),(22,'','','','','','','','2020-11-16 09:40:50'),(23,'BULLET 350','SHIBU ANSILY K','7736228956','shibusunithaann@gmail.com','','North Paravur','26-11-2020','2020-11-25 02:35:03'),(24,'','','','','','','','2020-11-29 14:22:48'),(25,'Interceptor 650','Rishi','9349980169','rishikeshoptra@gmail.com','Tried calling but no response ','Aluva','17-02-2021','2021-02-17 00:24:55'),(26,'','','','','','','','2021-02-23 09:16:24'),(27,'','','','','','','','2021-03-21 18:34:14'),(28,'','','','','','','','2021-05-11 23:43:18'),(29,'','','','','','','','2021-05-25 07:36:22'),(30,'','','','','','','','2021-05-31 06:14:26'),(31,'','','','','','','','2021-06-02 13:22:56'),(32,'','','','','','','','2021-06-23 08:07:08'),(33,'','','','','','','','2021-07-07 10:20:37'),(34,'','','','','','','','2021-07-13 18:29:54'),(35,'','','','','','','','2021-07-15 23:49:58'),(36,'','','','','','','','2021-08-05 12:17:43'),(37,'','','','','','','','2021-08-18 04:13:52'),(38,'','','','','','','','2021-08-20 08:08:56'),(39,'','','','','','','','2021-09-09 14:18:30'),(40,'','','','','','','','2021-09-19 03:01:26'),(41,'','','','','','','','2021-10-11 10:54:45'),(42,'','','','','','','','2021-10-23 09:09:16'),(43,'','','','','','','','2021-10-25 09:43:45'),(44,'','','','','','','','2021-11-24 13:51:52'),(45,'','','','','','','','2021-11-26 16:21:45'),(46,'','','','','','','','2021-12-28 02:55:33'),(47,'','','','','','','','2021-12-28 21:53:17'),(48,'','','','','','','','2021-12-31 01:07:37'),(49,'Interceptor 650','Jeby Paul','8921550739','','','Aluva','14-01-2022','2022-01-12 09:09:41'),(50,'','','','','','','','2022-01-27 03:23:02'),(51,'','','','','','','','2022-01-30 13:39:30'),(52,'','','','','','','','2022-02-01 08:00:07'),(53,'','','','','','','','2022-02-28 16:08:36'),(54,'','','','','','','','2022-03-12 15:22:11'),(55,'','','','','','','','2022-03-14 18:43:18'),(56,'Interceptor 650','Rahul','8086366366','rahulipply@gmail.com','','North Paravur','03-04-2022','2022-04-01 00:25:38'),(57,'','','','','','','','2022-04-12 18:37:36'),(58,'','','','','','','','2022-05-08 22:32:19'),(59,'','','','','','','','2022-05-11 02:14:38'),(60,'','','','','','','','2022-05-12 11:32:55'),(61,'','','','','','','','2022-05-15 22:02:24'),(62,'','','','','','','','2022-05-18 02:02:29'),(63,'','','','','','','','2022-07-15 21:36:10'),(64,'','','','','','','','2022-08-10 10:26:26'),(65,'','','','','','','','2022-08-16 12:43:07'),(66,'','','','','','','','2022-08-18 11:33:42'),(67,'','','','','','','','2022-09-10 04:15:36'),(68,'','','','','','','','2022-09-12 06:26:28'),(69,'','','','','','','','2022-09-13 15:48:51'),(70,'','','','','','','','2022-09-13 21:17:10'),(71,'','','','','','','','2022-12-07 21:53:26'),(72,'','','','','','','','2022-12-08 00:08:57'),(73,'','','','','','','','2022-12-08 08:49:26'),(74,'Classic 350 BS IV','amal ','7510248122','akb137635@gmail.com','only Sunday','North Paravur','26-02-2023','2023-02-21 02:46:17'),(75,'','Maura','(08) 9086 ','mauragracia@whale-mail.com','migliore farmacia online cialis generic viagra and cialis online generic cialis tadalafil generico cialis \r\nonline cialis online canada reviews','','','2023-03-22 23:14:26'),(76,'BULLET 350 ES','Hello World! https://racetrack.top/go/giywczjtmm5dinbs?hs=04ee3616b92b8c6c61242eec8df720af&','2536208817','ayfkuh@tofeat.com','ebuzrd','North Paravur','pt4oke','2023-04-10 11:07:04'),(77,'','','','','','','','2023-09-01 19:48:03'),(78,'','','','','','','','2023-09-13 09:13:23'),(79,'','','','','','','','2023-10-01 06:47:35'),(80,'','','','','','','','2023-10-06 12:32:34'),(81,'','','','','','','','2023-10-10 10:05:14');
/*!40000 ALTER TABLE `tbl_testdrive` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tbl_user`
--

DROP TABLE IF EXISTS `tbl_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tbl_user` (
  `tbl_User_Id` int(11) NOT NULL AUTO_INCREMENT,
  `FirstNm` varchar(50) NOT NULL,
  `LastNm` varchar(50) NOT NULL,
  `Orgnizatn_Id` int(11) NOT NULL,
  `Usr_Rol` char(20) NOT NULL,
  `emailId` varchar(50) NOT NULL,
  `UsrDesig` char(30) NOT NULL,
  `Usr_Ph` varchar(20) NOT NULL,
  `Pswrd` varchar(100) NOT NULL,
  `status` char(20) NOT NULL,
  `DateModified` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ModifiedBy` char(20) NOT NULL,
  `UserPhoto` varchar(50) NOT NULL,
  `UserLog` int(11) NOT NULL,
  PRIMARY KEY (`tbl_User_Id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_user`
--

LOCK TABLES `tbl_user` WRITE;
/*!40000 ALTER TABLE `tbl_user` DISABLE KEYS */;
INSERT INTO `tbl_user` VALUES (1,'Administrator','',2,'1','admin@gmail.com','','0','21232f297a57a5a743894a0e4a801fc3','active','2017-11-08 15:04:36','1','',1);
/*!40000 ALTER TABLE `tbl_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(100) NOT NULL,
  `user_email` varchar(100) NOT NULL,
  `user_phone` varchar(11) NOT NULL,
  `user_pass` varchar(100) NOT NULL,
  `user_status` varchar(30) NOT NULL DEFAULT 'active',
  `entry_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `user_country` varchar(100) NOT NULL,
  `user_state` varchar(100) NOT NULL,
  `user_district` varchar(100) NOT NULL,
  `user_number` varchar(100) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Laiju George','laijugeorge123@gmail.com','9744458578','d499f29b28b0caac028829ff2d728130','active','2020-05-16 15:55:30','','','','EUNOIA1'),(2,'Laiju George','laijugeorge123@gmail.com','9744458578','d499f29b28b0caac028829ff2d728130','active','2020-05-16 15:57:00','','','','EUNOIA2'),(3,'Laiju George','laijugeorge123@gmail.com','9744458578','d499f29b28b0caac028829ff2d728130','active','2020-05-16 15:57:48','','','','EUNOIA3'),(4,'Laiju George','laijugeorge123@gmail.com','9744458578','d499f29b28b0caac028829ff2d728130','active','2020-05-16 15:57:56','','','','EUNOIA4'),(5,'Laiju George','laijugeorge123@gmail.com','9744458578','d499f29b28b0caac028829ff2d728130','active','2020-05-16 15:57:59','','','','EUNOIA5'),(6,'Laiju George','laijugeorge123@gmail.com','9744458578','d499f29b28b0caac028829ff2d728130','active','2020-05-16 16:01:09','','','','EUNOIA6');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `video`
--

DROP TABLE IF EXISTS `video`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `video` (
  `Vi_ID` int(11) NOT NULL AUTO_INCREMENT,
  `Vi_Title` text NOT NULL,
  `Vi_Video` text NOT NULL,
  `Vi_Description` text NOT NULL,
  `Vi_Status` text NOT NULL,
  `User_ID` int(11) NOT NULL,
  `Ed_ID` int(11) NOT NULL,
  `entry_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`Vi_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `video`
--

LOCK TABLES `video` WRITE;
/*!40000 ALTER TABLE `video` DISABLE KEYS */;
/*!40000 ALTER TABLE `video` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'urbanlocomote'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-28 22:24:12
